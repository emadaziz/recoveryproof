import os,secrets,hashlib,hmac,time,base64,io,smtplib,ssl,uuid
from datetime import datetime,timezone,timedelta,date
from email.message import EmailMessage
from urllib.parse import quote_plus
from cryptography.fernet import Fernet
import pyotp
from argon2 import PasswordHasher
from fastapi import FastAPI,Depends,HTTPException,Request,Response,Body,Header,Query
from fastapi.responses import JSONResponse,StreamingResponse,Response as FastResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel,Field,field_validator
from sqlalchemy import create_engine,String,Integer,DateTime,Date,ForeignKey,Boolean,Text,select,func,UniqueConstraint
from sqlalchemy.orm import DeclarativeBase,Mapped,mapped_column,sessionmaker,Session
from prometheus_client import Counter,Histogram,Gauge,generate_latest,CONTENT_TYPE_LATEST
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
UTC=timezone.utc
def now():return datetime.now(UTC)
DB_PASSWORD=os.environ['DB_PASSWORD'];SECRET=os.environ['APP_SECRET'];COOKIE_SECURE=os.getenv('COOKIE_SECURE','false').lower()=='true'
engine=create_engine(f'postgresql+psycopg://recoveryproof:{quote_plus(DB_PASSWORD)}@db/recoveryproof',pool_pre_ping=True);SessionLocal=sessionmaker(engine,expire_on_commit=False);ph=PasswordHasher(time_cost=3,memory_cost=65536,parallelism=2);FERNET=Fernet(base64.urlsafe_b64encode(hashlib.sha256(SECRET.encode()).digest()));limiter=Limiter(key_func=get_remote_address)
class Base(DeclarativeBase):pass
class Org(Base):__tablename__='orgs';id:Mapped[int]=mapped_column(primary_key=True);name:Mapped[str]=mapped_column(String(120));created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class User(Base):__tablename__='users';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(ForeignKey('orgs.id'));email:Mapped[str]=mapped_column(String(254),unique=True,index=True);password_hash:Mapped[str]=mapped_column(Text);role:Mapped[str]=mapped_column(String(30),default='admin');active:Mapped[bool]=mapped_column(Boolean,default=True)
class WebSession(Base):__tablename__='web_sessions';id:Mapped[int]=mapped_column(primary_key=True);user_id:Mapped[int]=mapped_column(ForeignKey('users.id'),index=True);digest:Mapped[str]=mapped_column(String(64),unique=True,index=True);csrf_digest:Mapped[str]=mapped_column(String(64));expires_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),index=True);revoked:Mapped[bool]=mapped_column(Boolean,default=False);created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class MFA(Base):__tablename__='mfa';id:Mapped[int]=mapped_column(primary_key=True);user_id:Mapped[int]=mapped_column(ForeignKey('users.id'),unique=True,index=True);secret:Mapped[str]=mapped_column(Text);enabled:Mapped[bool]=mapped_column(Boolean,default=False)
class ResetToken(Base):__tablename__='reset_tokens';id:Mapped[int]=mapped_column(primary_key=True);user_id:Mapped[int]=mapped_column(ForeignKey('users.id'));digest:Mapped[str]=mapped_column(String(64),unique=True);expires_at:Mapped[datetime]=mapped_column(DateTime(timezone=True));used_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)
class System(Base):__tablename__='systems';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);name:Mapped[str]=mapped_column(String(120));criticality:Mapped[str]=mapped_column(String(20));rpo_minutes:Mapped[int]=mapped_column(Integer);rto_minutes:Mapped[int]=mapped_column(Integer);owner:Mapped[str|None]=mapped_column(String(120),nullable=True)
class Agent(Base):__tablename__='agents';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);name:Mapped[str]=mapped_column(String(120));token_digest:Mapped[str]=mapped_column(String(64),unique=True);revoked:Mapped[bool]=mapped_column(Boolean,default=False);expires_at:Mapped[datetime]=mapped_column(DateTime(timezone=True));last_seen:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)
class Check(Base):__tablename__='checks';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);system_id:Mapped[int]=mapped_column(index=True);agent_id:Mapped[int]=mapped_column();status:Mapped[str]=mapped_column(String(20));newest_file_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True);file_count:Mapped[int]=mapped_column(Integer);total_bytes:Mapped[int]=mapped_column(Integer);received_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Restore(Base):__tablename__='restores';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);system_id:Mapped[int]=mapped_column(index=True);result:Mapped[str]=mapped_column(String(20));duration_minutes:Mapped[int]=mapped_column(Integer);evidence_ref:Mapped[str|None]=mapped_column(String(250),nullable=True);notes:Mapped[str|None]=mapped_column(Text,nullable=True);tested_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Snapshot(Base):__tablename__='snapshots';__table_args__=(UniqueConstraint('org_id','snapshot_date'),);id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);snapshot_date:Mapped[date]=mapped_column(Date);score:Mapped[int]=mapped_column(Integer);alerts:Mapped[int]=mapped_column(Integer)
class Plugin(Base):__tablename__='plugins';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);code:Mapped[str]=mapped_column(String(80));name:Mapped[str]=mapped_column(String(120));enabled:Mapped[bool]=mapped_column(Boolean,default=False);version:Mapped[str]=mapped_column(String(30),default='1.0.0')
class Crisis(Base):__tablename__='crises';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);reference:Mapped[str]=mapped_column(String(40),unique=True);title:Mapped[str]=mapped_column(String(160));crisis_type:Mapped[str]=mapped_column(String(40));severity:Mapped[str]=mapped_column(String(10));status:Mapped[str]=mapped_column(String(40),default='declared');summary:Mapped[str]=mapped_column(Text);business_impact:Mapped[str|None]=mapped_column(Text,nullable=True);personal_data:Mapped[bool]=mapped_column(Boolean,default=False);detected_at:Mapped[datetime]=mapped_column(DateTime(timezone=True));declared_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now);commander:Mapped[str]=mapped_column(String(120));next_briefing_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)
class CrisisMember(Base):__tablename__='crisis_members';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);crisis_id:Mapped[int]=mapped_column(ForeignKey('crises.id'));name:Mapped[str]=mapped_column(String(120));role:Mapped[str]=mapped_column(String(80));cell:Mapped[str]=mapped_column(String(30));contact:Mapped[str|None]=mapped_column(String(180),nullable=True)
class CrisisEntry(Base):__tablename__='crisis_entries';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);crisis_id:Mapped[int]=mapped_column(ForeignKey('crises.id'));entry_type:Mapped[str]=mapped_column(String(30));title:Mapped[str]=mapped_column(String(160));details:Mapped[str]=mapped_column(Text);owner:Mapped[str|None]=mapped_column(String(120),nullable=True);status:Mapped[str]=mapped_column(String(30),default='open');created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class CrisisStep(Base):__tablename__='crisis_steps';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);crisis_id:Mapped[int]=mapped_column(ForeignKey('crises.id'));phase:Mapped[str]=mapped_column(String(20));step_order:Mapped[int]=mapped_column(Integer);code:Mapped[str]=mapped_column(String(50));title:Mapped[str]=mapped_column(String(180));description:Mapped[str]=mapped_column(Text);status:Mapped[str]=mapped_column(String(30),default='pending');owner:Mapped[str|None]=mapped_column(String(120),nullable=True);evidence_ref:Mapped[str|None]=mapped_column(String(250),nullable=True)
class Audit(Base):__tablename__='audit';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);actor:Mapped[str]=mapped_column(String(254));action:Mapped[str]=mapped_column(String(100));resource:Mapped[str]=mapped_column(String(150));at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Bootstrap(BaseModel):
 org_name:str=Field(min_length=2);email:str;password:str=Field(min_length=12)
 @field_validator('password')
 @classmethod
 def strong(cls,v):
  if not all([any(c.isupper() for c in v),any(c.islower() for c in v),any(c.isdigit() for c in v),any(not c.isalnum() for c in v)]):raise ValueError('Majuscule, minuscule, chiffre et caractère spécial requis')
  return v
class Login(BaseModel):email:str;password:str;totp_code:str|None=None
class Forgot(BaseModel):email:str
class ResetIn(BaseModel):token:str;password:str=Field(min_length=12)
class SystemIn(BaseModel):name:str;criticality:str=Field(pattern='^(low|medium|high|critical)$');rpo_minutes:int=Field(ge=1);rto_minutes:int=Field(ge=1);owner:str|None=None
class AgentIn(BaseModel):name:str;expires_days:int=Field(default=30,ge=1,le=365)
class CheckIn(BaseModel):system_id:int;status:str=Field(pattern='^(ok|warning|critical)$');newest_file_at:datetime|None=None;file_count:int=Field(ge=0);total_bytes:int=Field(ge=0)
class RestoreIn(BaseModel):system_id:int;result:str=Field(pattern='^(success|partial|failed)$');duration_minutes:int=Field(ge=0);evidence_ref:str|None=None;notes:str|None=None
class MFAEnable(BaseModel):code:str=Field(pattern='^[0-9]{6}$')
class CrisisIn(BaseModel):title:str=Field(min_length=3);crisis_type:str;severity:str=Field(pattern='^N[1-4]$');summary:str=Field(min_length=10);business_impact:str|None=None;personal_data:bool=False;detected_at:datetime;commander:str;next_briefing_at:datetime|None=None
class MemberIn(BaseModel):name:str;role:str;cell:str=Field(pattern='^(strategic|operational|communication)$');contact:str|None=None
class EntryIn(BaseModel):entry_type:str;title:str;details:str;owner:str|None=None
class StepIn(BaseModel):status:str;owner:str|None=None;evidence_ref:str|None=None
def db():
 s=SessionLocal()
 try:yield s
 finally:s.close()
def dg(x):return hmac.new(SECRET.encode(),x.encode(),hashlib.sha256).hexdigest()
def issue(response,u,s):
 raw=secrets.token_urlsafe(48);csrf=secrets.token_urlsafe(32);s.add(WebSession(user_id=u.id,digest=dg(raw),csrf_digest=dg(csrf),expires_at=now()+timedelta(minutes=30)));s.commit();response.set_cookie('rp_session',raw,httponly=True,samesite='strict',secure=COOKIE_SECURE,max_age=1800);response.set_cookie('rp_csrf',csrf,httponly=False,samesite='strict',secure=COOKIE_SECURE,max_age=1800);return {'authenticated':True}
def current(request:Request,s:Session=Depends(db)):
 raw=request.cookies.get('rp_session');rec=s.scalar(select(WebSession).where(WebSession.digest==dg(raw or ''),WebSession.revoked==False,WebSession.expires_at>now()))
 if not rec:raise HTTPException(401,'Session invalide ou expirée')
 return s.get(User,rec.user_id)
def csrf(request:Request,s:Session=Depends(db)):
 raw=request.cookies.get('rp_session');c=request.cookies.get('rp_csrf');h=request.headers.get('x-csrf-token');rec=s.scalar(select(WebSession).where(WebSession.digest==dg(raw or ''),WebSession.revoked==False))
 if not rec or not c or not h or not hmac.compare_digest(c,h) or not hmac.compare_digest(rec.csrf_digest,dg(c)):raise HTTPException(403,'CSRF invalide')
def audit(s,u,a,r):s.add(Audit(org_id=u.org_id,actor=u.email,action=a,resource=r))
def org_obj(s,model,i,org):
 x=s.scalar(select(model).where(model.id==i,model.org_id==org))
 if not x:raise HTTPException(404,'Ressource introuvable')
 return x
PCA=[('PCA%02d'%i,t) for i,t in enumerate(['Qualifier les activités essentielles','Activer la gouvernance de crise','Sécuriser les communications','Déclencher le mode dégradé','Prioriser les ressources','Informer les parties prenantes','Piloter la continuité','Tenir les points de situation','Préparer la transition vers le PRA','Clôturer le mode dégradé'],1)]
PRA=[('PRA%02d'%i,t) for i,t in enumerate(['Confirmer le périmètre','Contenir et préserver les preuves','Valider un point de restauration sain','Préparer un environnement propre','Restaurer l’infrastructure','Restaurer les données','Restaurer les applications','Contrôler sécurité et intégrité','Réaliser les tests techniques','Obtenir la validation métier','Rouvrir progressivement','Surveiller de manière renforcée','Revenir au nominal','Clôturer et ouvrir le RETEX'],1)]
REQ=Counter('recoveryproof_http_requests_total','Requests',['method','path','status']);LAT=Histogram('recoveryproof_http_request_seconds','Latency',['method','path']);AGOFF=Gauge('recoveryproof_agents_offline','Offline agents');OUTRPO=Gauge('recoveryproof_systems_outside_rpo','Outside RPO');RFAIL=Gauge('recoveryproof_restore_tests_failed','Restore failed');CACT=Gauge('recoveryproof_crises_active','Active crises')
app=FastAPI(title='RecoveryProof',version='0.8.2',docs_url=None);app.state.limiter=limiter;app.add_middleware(SlowAPIMiddleware);app.add_middleware(CORSMiddleware,allow_origins=['http://localhost:8080'],allow_credentials=True,allow_methods=['*'],allow_headers=['Content-Type','X-CSRF-Token'])
@app.middleware('http')
async def metr(request,call_next):
 st=time.monotonic();r=await call_next(request);REQ.labels(request.method,request.url.path,str(r.status_code)).inc();LAT.labels(request.method,request.url.path).observe(time.monotonic()-st);r.headers['X-Request-ID']='req_'+uuid.uuid4().hex[:16];return r
@app.on_event('startup')
def startup():Base.metadata.create_all(engine)
@app.get('/health')
def health():return {'status':'ok','version':'0.8.2','time':now()}
@app.get('/metrics',include_in_schema=False)
def metrics(s:Session=Depends(db)):
 current_time=now()
 agents_offline=s.scalar(select(func.count(Agent.id)).where((Agent.revoked==False)&((Agent.last_seen==None)|(Agent.last_seen<current_time-timedelta(hours=2))))) or 0
 systems_outside_rpo=0
 for system in s.scalars(select(System)).all():
  last_check=s.scalar(select(Check).where(Check.org_id==system.org_id,Check.system_id==system.id).order_by(Check.received_at.desc()))
  if not last_check or not last_check.newest_file_at:
   systems_outside_rpo+=1
   continue
  age_minutes=(current_time-last_check.newest_file_at).total_seconds()/60
  if age_minutes>system.rpo_minutes or last_check.status!='ok':systems_outside_rpo+=1
 failed_restores=s.scalar(select(func.count(Restore.id)).where(Restore.result=='failed')) or 0
 active_crises=s.scalar(select(func.count(Crisis.id)).where(Crisis.status.notin_(['closed','retex']))) or 0
 AGOFF.set(agents_offline);OUTRPO.set(systems_outside_rpo);RFAIL.set(failed_restores);CACT.set(active_crises)
 return FastResponse(generate_latest(),media_type=CONTENT_TYPE_LATEST)
@app.get('/setup/status')
def setup(s:Session=Depends(db)):return {'required':not bool(s.scalar(select(func.count(User.id))))}
@app.post('/setup/bootstrap',status_code=201)
def bootstrap(response:Response,x:Bootstrap=Body(...),s:Session=Depends(db)):
 if s.scalar(select(func.count(User.id))):raise HTTPException(409,'Déjà initialisé')
 o=Org(name=x.org_name);s.add(o);s.flush();u=User(org_id=o.id,email=x.email.lower(),password_hash=ph.hash(x.password));s.add(u);s.flush();return issue(response,u,s)
@app.post('/auth/login')
@limiter.limit('5/minute')
def login(request:Request,response:Response,x:Login=Body(...),s:Session=Depends(db)):
 u=s.scalar(select(User).where(User.email==x.email.lower()))
 try:ok=bool(u and ph.verify(u.password_hash,x.password))
 except:ok=False
 if not ok:raise HTTPException(401,'Identifiants invalides')
 m=s.scalar(select(MFA).where(MFA.user_id==u.id,MFA.enabled==True))
 if m:
  if not x.totp_code:raise HTTPException(428,'Code MFA requis')
  if not pyotp.TOTP(FERNET.decrypt(m.secret.encode()).decode()).verify(x.totp_code,valid_window=1):raise HTTPException(401,'Code MFA invalide')
 return issue(response,u,s)
@app.post('/auth/logout',status_code=204)
def logout(request:Request,response:Response,s:Session=Depends(db),ok=Depends(csrf)):
 rec=s.scalar(select(WebSession).where(WebSession.digest==dg(request.cookies.get('rp_session',''))));
 if rec:rec.revoked=True;s.commit()
 response.delete_cookie('rp_session');response.delete_cookie('rp_csrf')
@app.get('/me')
def me(u:User=Depends(current),s:Session=Depends(db)):return {'email':u.email,'organization':s.get(Org,u.org_id).name,'role':u.role}
@app.post('/auth/forgot-password',status_code=202)
def forgot(request:Request,x:Forgot=Body(...),s:Session=Depends(db)):
 u=s.scalar(select(User).where(User.email==x.email.lower()))
 if u:
  raw=secrets.token_urlsafe(48);s.add(ResetToken(user_id=u.id,digest=dg(raw),expires_at=now()+timedelta(minutes=15)));s.commit();msg=EmailMessage();msg['Subject']='Réinitialisation RecoveryProof';msg['From']='RecoveryProof <no-reply@recoveryproof.local>';msg['To']=u.email;msg.set_content(f"Lien valable 15 minutes : {request.url.scheme}://{request.headers.get('host')}/?reset={raw}")
  with smtplib.SMTP(os.getenv('SMTP_HOST','mailpit'),int(os.getenv('SMTP_PORT','1025'))) as smtp:smtp.send_message(msg)
 return {'message':'Si cette adresse existe, un e-mail a été envoyé.'}
@app.post('/auth/reset-password')
def reset_password(x:ResetIn=Body(...),s:Session=Depends(db)):
 r=s.scalar(select(ResetToken).where(ResetToken.digest==dg(x.token),ResetToken.used_at==None,ResetToken.expires_at>now()))
 if not r:raise HTTPException(400,'Lien invalide ou expiré')
 u=s.get(User,r.user_id);u.password_hash=ph.hash(x.password);r.used_at=now();s.query(WebSession).filter(WebSession.user_id==u.id).update({'revoked':True});s.commit();return {'message':'Mot de passe remplacé'}
@app.get('/auth/mfa/status')
def mfa_status(u:User=Depends(current),s:Session=Depends(db)):m=s.scalar(select(MFA).where(MFA.user_id==u.id));return {'enabled':bool(m and m.enabled)}
@app.post('/auth/mfa/setup')
def mfa_setup(u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):
 sec=pyotp.random_base32();m=s.scalar(select(MFA).where(MFA.user_id==u.id)) or MFA(user_id=u.id,secret='');m.secret=FERNET.encrypt(sec.encode()).decode();m.enabled=False;s.add(m);s.commit();return {'secret':sec}
@app.post('/auth/mfa/enable')
def mfa_enable(x:MFAEnable=Body(...),u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):
 m=s.scalar(select(MFA).where(MFA.user_id==u.id));sec=FERNET.decrypt(m.secret.encode()).decode()
 if not pyotp.TOTP(sec).verify(x.code,valid_window=1):raise HTTPException(400,'Code invalide')
 m.enabled=True;s.commit();return {'enabled':True}
def detail(s,x):
 c=s.scalar(select(Check).where(Check.org_id==x.org_id,Check.system_id==x.id).order_by(Check.received_at.desc()));r=s.scalar(select(Restore).where(Restore.org_id==x.org_id,Restore.system_id==x.id).order_by(Restore.tested_at.desc()));age=(now()-c.newest_file_at).total_seconds()/60 if c and c.newest_file_at else None;backup=age is not None and age<=x.rpo_minutes and c.status=='ok';agent=s.get(Agent,c.agent_id) if c else None;agentok=bool(agent and agent.last_seen and now()-agent.last_seen<timedelta(minutes=max(120,x.rpo_minutes)));restore=bool(r and r.result=='success' and now()-r.tested_at<timedelta(days=90));rto=bool(r and r.result=='success' and r.duration_minutes<=x.rto_minutes);evid=bool(r and r.evidence_ref);score=(35 if backup else 0)+(15 if agentok else 0)+(30 if restore else 0)+(10 if rto else 0)+(10 if evid else 0);actions=[]
 if not backup:actions.append('Sauvegarde absente ou hors RPO')
 if not agentok:actions.append('Agent inactif')
 if not restore:actions.append('Test de restauration à planifier')
 if not evid:actions.append('Preuve manquante')
 return {'id':x.id,'name':x.name,'criticality':x.criticality,'rpo_minutes':x.rpo_minutes,'rto_minutes':x.rto_minutes,'owner':x.owner,'backup_age_minutes':round(age) if age is not None else None,'restore_result':r.result if r else None,'restore_at':r.tested_at if r else None,'score':score,'state':'ok' if score>=70 else 'warning' if score>=40 else 'critical','actions':actions,'breakdown':{'backup':35 if backup else 0,'agent':15 if agentok else 0,'restore':30 if restore else 0,'rto':10 if rto else 0,'evidence':10 if evid else 0}}
@app.get('/systems')
def systems(u:User=Depends(current),s:Session=Depends(db)):return [detail(s,x) for x in s.scalars(select(System).where(System.org_id==u.org_id))]
@app.post('/systems',status_code=201)
def add_system(x:SystemIn=Body(...),u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):
 o=System(org_id=u.org_id,**x.model_dump());s.add(o);s.flush();audit(s,u,'system.create',str(o.id));s.commit();return o
@app.delete('/systems/{i}',status_code=204)
def del_system(i:int,u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):s.delete(org_obj(s,System,i,u.org_id));s.commit()
@app.get('/agents')
def agents(u:User=Depends(current),s:Session=Depends(db)):return [{'id':a.id,'name':a.name,'expires_at':a.expires_at,'last_seen':a.last_seen,'revoked':a.revoked} for a in s.scalars(select(Agent).where(Agent.org_id==u.org_id))]
@app.post('/agents',status_code=201)
def add_agent(x:AgentIn=Body(...),u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):
 raw='rpa_'+secrets.token_urlsafe(32);a=Agent(org_id=u.org_id,name=x.name,token_digest=dg(raw),expires_at=now()+timedelta(days=x.expires_days));s.add(a);s.commit();return {'token':raw,'warning':'Copiez ce jeton maintenant'}
def agent_auth(authorization:str=Header(default=''),s:Session=Depends(db)):
 if not authorization.startswith('Bearer rpa_'):raise HTTPException(401,'Jeton requis')
 a=s.scalar(select(Agent).where(Agent.token_digest==dg(authorization[7:])))
 if not a or a.revoked or a.expires_at<now():raise HTTPException(403,'Jeton invalide')
 return a
@app.post('/agent/checks',status_code=202)
def check(x:CheckIn=Body(...),a:Agent=Depends(agent_auth),s:Session=Depends(db)):
 org_obj(s,System,x.system_id,a.org_id);a.last_seen=now();s.add(Check(org_id=a.org_id,agent_id=a.id,**x.model_dump()));s.commit();return {'accepted':True}
@app.get('/restore-tests')
def restores(u:User=Depends(current),s:Session=Depends(db)):
 rows=s.execute(
  select(Restore,System.name)
  .join(System,System.id==Restore.system_id)
  .where(Restore.org_id==u.org_id,System.org_id==u.org_id)
  .order_by(Restore.tested_at.desc())
 ).all()
 return [
  {
   'id':restore.id,
   'system_id':restore.system_id,
   'system_name':system_name,
   'result':restore.result,
   'duration_minutes':restore.duration_minutes,
   'evidence_ref':restore.evidence_ref,
   'notes':restore.notes,
   'tested_at':restore.tested_at,
  }
  for restore,system_name in rows
 ]
@app.post('/restore-tests',status_code=201)
def add_restore(x:RestoreIn=Body(...),u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):
 org_obj(s,System,x.system_id,u.org_id);r=Restore(org_id=u.org_id,**x.model_dump());s.add(r);s.commit();return r
@app.get('/dashboard')
def dashboard(days:int=Query(30,ge=7,le=365),u:User=Depends(current),s:Session=Depends(db)):
 items=[detail(s,x) for x in s.scalars(select(System).where(System.org_id==u.org_id))];score=round(sum(x['score'] for x in items)/len(items)) if items else 0;alerts=sum(bool(x['actions']) for x in items);today=date.today();snap=s.scalar(select(Snapshot).where(Snapshot.org_id==u.org_id,Snapshot.snapshot_date==today))
 if not snap:s.add(Snapshot(org_id=u.org_id,snapshot_date=today,score=score,alerts=alerts));s.commit()
 hist=s.scalars(select(Snapshot).where(Snapshot.org_id==u.org_id,Snapshot.snapshot_date>=today-timedelta(days=days)).order_by(Snapshot.snapshot_date)).all();return {'readiness':score,'systems_total':len(items),'systems_protected':sum(x['state']=='ok' for x in items),'alerts':alerts,'restores_verified':sum(x['restore_result']=='success' for x in items),'items':items,'priorities':[{'system':x['name'],'message':a} for x in items for a in x['actions']][:8],'history':[{'date':h.snapshot_date.isoformat(),'score':h.score} for h in hist]}
@app.get('/reports/passport.pdf')
def report(u:User=Depends(current),s:Session=Depends(db)):
 d=dashboard(30,u,s);buf=io.BytesIO();c=canvas.Canvas(buf,pagesize=A4);c.setFont('Helvetica-Bold',18);c.drawString(40,800,'Recovery Passport');c.setFont('Helvetica',10);c.drawString(40,780,f'Organisation: {s.get(Org,u.org_id).name}');c.drawString(40,765,f'Indice: {d["readiness"]}/100');y=735
 for x in d['items']:
  c.drawString(40,y,f'{x["name"]} - {x["score"]}/100 - {x["state"]}');y-=16
 c.drawString(40,40,'Ce rapport reflète les contrôles documentés et ne garantit pas à lui seul la reprise.');c.save();buf.seek(0);return StreamingResponse(buf,media_type='application/pdf',headers={'Content-Disposition':'attachment; filename=recovery-passport.pdf'})
@app.get('/plugins')
def plugins(u:User=Depends(current),s:Session=Depends(db)):
 rows=s.scalars(select(Plugin).where(Plugin.org_id==u.org_id)).all()
 if not rows:s.add_all([Plugin(org_id=u.org_id,code='filesystem',name='Filesystem'),Plugin(org_id=u.org_id,code='proxmox',name='Proxmox'),Plugin(org_id=u.org_id,code='webhook',name='Webhook')]);s.commit();rows=s.scalars(select(Plugin).where(Plugin.org_id==u.org_id)).all()
 return rows
@app.get('/crises')
def crises(u:User=Depends(current),s:Session=Depends(db)):return s.scalars(select(Crisis).where(Crisis.org_id==u.org_id).order_by(Crisis.declared_at.desc())).all()
@app.post('/crises',status_code=201)
def create_crisis(x:CrisisIn=Body(...),u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):
 ref=f'CRISE-{now().year}-{(s.scalar(select(func.count(Crisis.id)).where(Crisis.org_id==u.org_id)) or 0)+1:03d}';c=Crisis(org_id=u.org_id,reference=ref,**x.model_dump());s.add(c);s.flush()
 for phase,steps in [('PCA',PCA),('PRA',PRA)]:
  for n,(code,title) in enumerate(steps,1):s.add(CrisisStep(org_id=u.org_id,crisis_id=c.id,phase=phase,step_order=n,code=code,title=title,description=title))
 s.add(CrisisEntry(org_id=u.org_id,crisis_id=c.id,entry_type='fact',title='Crise déclarée',details=x.summary,owner=u.email,status='completed'));audit(s,u,'crisis.declare',ref);s.commit();s.refresh(c);return c
@app.get('/crises/{i}')
def crisis(i:int,u:User=Depends(current),s:Session=Depends(db)):
 c=org_obj(s,Crisis,i,u.org_id);return {'crisis':c,'members':s.scalars(select(CrisisMember).where(CrisisMember.crisis_id==i,CrisisMember.org_id==u.org_id)).all(),'entries':s.scalars(select(CrisisEntry).where(CrisisEntry.crisis_id==i,CrisisEntry.org_id==u.org_id).order_by(CrisisEntry.created_at.desc())).all(),'steps':s.scalars(select(CrisisStep).where(CrisisStep.crisis_id==i,CrisisStep.org_id==u.org_id).order_by(CrisisStep.phase,CrisisStep.step_order)).all()}
@app.post('/crises/{i}/members',status_code=201)
def member(i:int,x:MemberIn=Body(...),u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):org_obj(s,Crisis,i,u.org_id);m=CrisisMember(org_id=u.org_id,crisis_id=i,**x.model_dump());s.add(m);s.commit();return m
@app.post('/crises/{i}/entries',status_code=201)
def entry(i:int,x:EntryIn=Body(...),u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):org_obj(s,Crisis,i,u.org_id);e=CrisisEntry(org_id=u.org_id,crisis_id=i,**x.model_dump());s.add(e);s.commit();return e
@app.post('/crises/{i}/steps/{sid}')
def step(i:int,sid:int,x:StepIn=Body(...),u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):
 st=org_obj(s,CrisisStep,sid,u.org_id)
 if st.crisis_id!=i:raise HTTPException(404,'Étape introuvable')
 st.status=x.status;st.owner=x.owner;st.evidence_ref=x.evidence_ref;s.commit();return {'updated':True}
@app.get('/settings')
def settings(u:User=Depends(current)):return {'current_version':'0.8.2','session_minutes':30,'update_channel':'stable'}
@app.get('/updates/check')
def updates(u:User=Depends(current)):return {'current':'0.8.2','latest':'0.8.2','status':'up_to_date','signed_updates_required':True}
@app.get('/audit')
def audits(u:User=Depends(current),s:Session=Depends(db)):return s.scalars(select(Audit).where(Audit.org_id==u.org_id).order_by(Audit.at.desc()).limit(100)).all()
