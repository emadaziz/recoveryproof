import os,secrets,hashlib,hmac,time,io
from datetime import datetime,timezone,timedelta,date
from urllib.parse import quote_plus
import jwt
from argon2 import PasswordHasher
from fastapi import FastAPI,Depends,HTTPException,Request,Header,Body,Query
from fastapi.responses import StreamingResponse,JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel,Field
from sqlalchemy import create_engine,String,Integer,DateTime,Date,ForeignKey,Boolean,Text,select,func,UniqueConstraint
from sqlalchemy.orm import DeclarativeBase,Mapped,mapped_column,sessionmaker,Session
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
UTC=timezone.utc
def now():return datetime.now(UTC)
DB_PASSWORD=os.environ['DB_PASSWORD'];SECRET=os.environ['APP_SECRET']
engine=create_engine(f'postgresql+psycopg://recoveryproof:{quote_plus(DB_PASSWORD)}@db/recoveryproof',pool_pre_ping=True)
SessionLocal=sessionmaker(engine,expire_on_commit=False);ph=PasswordHasher(time_cost=3,memory_cost=65536,parallelism=2);oauth=OAuth2PasswordBearer(tokenUrl='/api/auth/login');limiter=Limiter(key_func=get_remote_address)
class Base(DeclarativeBase):pass
class Org(Base):
 __tablename__='orgs';id:Mapped[int]=mapped_column(primary_key=True);name:Mapped[str]=mapped_column(String(120));created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class User(Base):
 __tablename__='users';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(ForeignKey('orgs.id'));email:Mapped[str]=mapped_column(String(254),unique=True,index=True);password_hash:Mapped[str]=mapped_column(Text);role:Mapped[str]=mapped_column(String(30),default='admin');active:Mapped[bool]=mapped_column(Boolean,default=True)
class System(Base):
 __tablename__='systems';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);name:Mapped[str]=mapped_column(String(120));criticality:Mapped[str]=mapped_column(String(20));rpo_hours:Mapped[int]=mapped_column(Integer);rto_hours:Mapped[int]=mapped_column(Integer);owner:Mapped[str|None]=mapped_column(String(120),nullable=True);created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Agent(Base):
 __tablename__='agents';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);name:Mapped[str]=mapped_column(String(120));token_digest:Mapped[str]=mapped_column(String(64),unique=True);revoked:Mapped[bool]=mapped_column(Boolean,default=False);expires_at:Mapped[datetime]=mapped_column(DateTime(timezone=True));last_seen:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)
class Check(Base):
 __tablename__='checks';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);system_id:Mapped[int]=mapped_column(index=True);agent_id:Mapped[int]=mapped_column();status:Mapped[str]=mapped_column(String(20));newest_file_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True);file_count:Mapped[int]=mapped_column(Integer);total_bytes:Mapped[int]=mapped_column(Integer);received_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,index=True)
class RestoreTest(Base):
 __tablename__='restore_tests';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);system_id:Mapped[int]=mapped_column(index=True);result:Mapped[str]=mapped_column(String(20));duration_minutes:Mapped[int]=mapped_column(Integer);evidence_ref:Mapped[str|None]=mapped_column(String(250),nullable=True);notes:Mapped[str|None]=mapped_column(Text,nullable=True);tested_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,index=True)
class Snapshot(Base):
 __tablename__='readiness_snapshots';__table_args__=(UniqueConstraint('org_id','snapshot_date'),);id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);snapshot_date:Mapped[date]=mapped_column(Date);score:Mapped[int]=mapped_column(Integer);protected:Mapped[int]=mapped_column(Integer);alerts:Mapped[int]=mapped_column(Integer);verified:Mapped[int]=mapped_column(Integer)
class Audit(Base):
 __tablename__='audit';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);actor:Mapped[str]=mapped_column(String(254));action:Mapped[str]=mapped_column(String(100));resource:Mapped[str]=mapped_column(String(150));at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Bootstrap(BaseModel):org_name:str=Field(min_length=2,max_length=120);email:str=Field(min_length=5,max_length=254);password:str=Field(min_length=12,max_length=200)
class Login(BaseModel):email:str;password:str
class SystemIn(BaseModel):name:str=Field(min_length=2,max_length=120);criticality:str=Field(pattern='^(low|medium|high|critical)$');rpo_hours:int=Field(ge=1,le=8760);rto_hours:int=Field(ge=1,le=8760);owner:str|None=None
class AgentIn(BaseModel):name:str=Field(min_length=2,max_length=120);expires_days:int=Field(default=30,ge=1,le=365)
class CheckIn(BaseModel):system_id:int;status:str=Field(pattern='^(ok|warning|critical)$');newest_file_at:datetime|None=None;file_count:int=Field(ge=0);total_bytes:int=Field(ge=0)
class RestoreIn(BaseModel):system_id:int;result:str=Field(pattern='^(success|partial|failed)$');duration_minutes:int=Field(ge=0,le=100000);evidence_ref:str|None=Field(default=None,max_length=250);notes:str|None=Field(default=None,max_length=2000)
def db():
 s=SessionLocal()
 try:yield s
 finally:s.close()
def dg(v):return hmac.new(SECRET.encode(),v.encode(),hashlib.sha256).hexdigest()
def session_token(u):return jwt.encode({'sub':str(u.id),'org':u.org_id,'exp':now()+timedelta(minutes=30)},SECRET,algorithm='HS256')
def current(token:str=Depends(oauth),s:Session=Depends(db)):
 try:d=jwt.decode(token,SECRET,algorithms=['HS256']);u=s.get(User,int(d['sub']))
 except Exception:raise HTTPException(401,'Session invalide ou expirée')
 if not u or not u.active:raise HTTPException(401,'Compte inactif')
 return u
def org_obj(s,model,i,org):
 o=s.scalar(select(model).where(model.id==i,model.org_id==org))
 if not o:raise HTTPException(404,'Ressource introuvable')
 return o
def audit(s,u,a,r):s.add(Audit(org_id=u.org_id,actor=u.email,action=a,resource=r))
def system_detail(s,sys):
 c=s.scalar(select(Check).where(Check.org_id==sys.org_id,Check.system_id==sys.id).order_by(Check.received_at.desc()))
 rt=s.scalar(select(RestoreTest).where(RestoreTest.org_id==sys.org_id,RestoreTest.system_id==sys.id).order_by(RestoreTest.tested_at.desc()))
 age=(now()-c.newest_file_at).total_seconds()/3600 if c and c.newest_file_at else None
 backup_ok=age is not None and age<=sys.rpo_hours and c.status=='ok';agent=s.get(Agent,c.agent_id) if c else None;agent_ok=bool(agent and agent.last_seen and now()-agent.last_seen<timedelta(hours=max(2,sys.rpo_hours)))
 restore_ok=bool(rt and rt.result=='success' and now()-rt.tested_at<timedelta(days=90));rto_ok=bool(rt and rt.result=='success' and rt.duration_minutes<=sys.rto_hours*60);evidence_ok=bool(rt and rt.evidence_ref)
 score=(35 if backup_ok else 0)+(15 if agent_ok else 0)+(30 if restore_ok else 0)+(10 if rto_ok else 0)+(10 if evidence_ok else 0)
 severity='critical' if not backup_ok and sys.criticality=='critical' else 'high' if not backup_ok else 'medium' if not restore_ok else 'info'
 actions=[]
 if not backup_ok:actions.append('Sauvegarde absente ou hors RPO')
 if not agent_ok:actions.append('Agent inactif ou jamais connecté')
 if not restore_ok:actions.append('Test de restauration à planifier')
 if rt and not rto_ok:actions.append('RTO non respecté')
 if not evidence_ok:actions.append('Preuve de restauration manquante')
 return {'id':sys.id,'name':sys.name,'criticality':sys.criticality,'rpo_hours':sys.rpo_hours,'rto_hours':sys.rto_hours,'owner':sys.owner,'backup_age_hours':round(age,1) if age is not None else None,'last_check':c.received_at if c else None,'agent_name':agent.name if agent else None,'agent_last_seen':agent.last_seen if agent else None,'restore_result':rt.result if rt else None,'restore_at':rt.tested_at if rt else None,'restore_minutes':rt.duration_minutes if rt else None,'evidence':rt.evidence_ref if rt else None,'score':score,'state':'ok' if score>=70 else 'warning' if score>=40 else 'critical','severity':severity,'actions':actions,'breakdown':{'backup':35 if backup_ok else 0,'agent':15 if agent_ok else 0,'restore':30 if restore_ok else 0,'rto':10 if rto_ok else 0,'evidence':10 if evidence_ok else 0}}
def dashboard_data(s,org,days=30):
 systems=s.scalars(select(System).where(System.org_id==org)).all();items=[system_detail(s,x) for x in systems];score=round(sum(x['score'] for x in items)/len(items)) if items else 0;protected=sum(x['state']=='ok' for x in items);verified=sum(x['restore_result']=='success' and x['restore_at'] and now()-x['restore_at']<timedelta(days=days) for x in items);alerts=sum(bool(x['actions']) for x in items)
 today=date.today();snap=s.scalar(select(Snapshot).where(Snapshot.org_id==org,Snapshot.snapshot_date==today))
 if not snap:snap=Snapshot(org_id=org,snapshot_date=today,score=score,protected=protected,alerts=alerts,verified=verified);s.add(snap)
 else:snap.score=score;snap.protected=protected;snap.alerts=alerts;snap.verified=verified
 s.commit();hist=s.scalars(select(Snapshot).where(Snapshot.org_id==org,Snapshot.snapshot_date>=today-timedelta(days=days)).order_by(Snapshot.snapshot_date)).all();priorities=[{'system_id':x['id'],'system':x['name'],'severity':x['severity'],'message':a} for x in items for a in x['actions']][:8]
 return {'readiness':score,'systems_total':len(items),'systems_protected':protected,'alerts':alerts,'restores_verified':verified,'items':items,'priorities':priorities,'history':[{'date':x.snapshot_date.isoformat(),'score':x.score} for x in hist],'period_days':days}
app=FastAPI(title='RecoveryProof API',version='0.4.0',docs_url=None,redoc_url=None);app.state.limiter=limiter;app.add_middleware(SlowAPIMiddleware);app.add_middleware(CORSMiddleware,allow_origins=['http://localhost:8080'],allow_methods=['GET','POST','DELETE'],allow_headers=['Authorization','Content-Type'])
@app.exception_handler(RateLimitExceeded)
async def limited(request,exc):return JSONResponse({'detail':'Trop de tentatives. Réessayez plus tard.'},429)
@app.on_event('startup')
def startup():Base.metadata.create_all(engine)
@app.get('/health')
def health():return {'status':'ok','version':'0.4.0','time':now()}
@app.get('/setup/status')
def setup_status(s:Session=Depends(db)):return {'required':not bool(s.scalar(select(func.count(User.id))))}
@app.post('/setup/bootstrap',status_code=201)
def bootstrap(x:Bootstrap=Body(...),s:Session=Depends(db)):
 if s.scalar(select(func.count(User.id))):raise HTTPException(409,'Déjà initialisé')
 o=Org(name=x.org_name);s.add(o);s.flush();u=User(org_id=o.id,email=x.email.lower(),password_hash=ph.hash(x.password));s.add(u);s.commit();return {'access_token':session_token(u)}
@app.post('/auth/login')
def login(x:Login=Body(...),s:Session=Depends(db)):
 u=s.scalar(select(User).where(User.email==x.email.lower()))
 try:ok=bool(u and ph.verify(u.password_hash,x.password))
 except Exception:ok=False
 if not ok:raise HTTPException(401,'Identifiants invalides')
 return {'access_token':session_token(u)}
@app.get('/me')
def me(u:User=Depends(current),s:Session=Depends(db)):return {'email':u.email,'organization':s.get(Org,u.org_id).name,'role':u.role}
@app.get('/systems')
def systems(u:User=Depends(current),s:Session=Depends(db)):return [system_detail(s,x) for x in s.scalars(select(System).where(System.org_id==u.org_id))]
@app.post('/systems',status_code=201)
def add_system(x:SystemIn=Body(...),u:User=Depends(current),s:Session=Depends(db)):
 o=System(org_id=u.org_id,**x.model_dump());s.add(o);s.flush();audit(s,u,'system.create',str(o.id));s.commit();return o
@app.delete('/systems/{i}',status_code=204)
def del_system(i:int,u:User=Depends(current),s:Session=Depends(db)):s.delete(org_obj(s,System,i,u.org_id));s.commit()
@app.get('/agents')
def agents(u:User=Depends(current),s:Session=Depends(db)):return [{'id':a.id,'name':a.name,'revoked':a.revoked,'expires_at':a.expires_at,'last_seen':a.last_seen} for a in s.scalars(select(Agent).where(Agent.org_id==u.org_id))]
@app.post('/agents',status_code=201)
def add_agent(x:AgentIn=Body(...),u:User=Depends(current),s:Session=Depends(db)):
 raw='rpa_'+secrets.token_urlsafe(32);a=Agent(org_id=u.org_id,name=x.name,token_digest=dg(raw),expires_at=now()+timedelta(days=x.expires_days));s.add(a);s.commit();return {'token':raw}
def agent_auth(authorization:str=Header(default=''),s:Session=Depends(db)):
 if not authorization.startswith('Bearer rpa_'):raise HTTPException(401,'Jeton requis')
 a=s.scalar(select(Agent).where(Agent.token_digest==dg(authorization[7:])))
 if not a or a.revoked or a.expires_at<now():raise HTTPException(403,'Jeton invalide')
 return a
@app.post('/agent/checks',status_code=202)
def check(x:CheckIn=Body(...),a:Agent=Depends(agent_auth),s:Session=Depends(db)):
 org_obj(s,System,x.system_id,a.org_id);a.last_seen=now();s.add(Check(org_id=a.org_id,agent_id=a.id,**x.model_dump()));s.commit();return {'accepted':True}
@app.get('/restore-tests')
def restores(u:User=Depends(current),s:Session=Depends(db)):return s.scalars(select(RestoreTest).where(RestoreTest.org_id==u.org_id).order_by(RestoreTest.tested_at.desc())).all()
@app.post('/restore-tests',status_code=201)
def restore(x:RestoreIn=Body(...),u:User=Depends(current),s:Session=Depends(db)):
 org_obj(s,System,x.system_id,u.org_id);r=RestoreTest(org_id=u.org_id,**x.model_dump());s.add(r);s.flush();audit(s,u,'restore.create',str(r.id));s.commit();return r
@app.get('/dashboard')
def dashboard(days:int=Query(30,ge=7,le=365),u:User=Depends(current),s:Session=Depends(db)):return dashboard_data(s,u.org_id,days)
@app.get('/reports/passport.pdf')
def report(u:User=Depends(current),s:Session=Depends(db)):
 d=dashboard_data(s,u.org_id,30);org=s.get(Org,u.org_id);buf=io.BytesIO();c=canvas.Canvas(buf,pagesize=A4);w,h=A4;c.setTitle('Recovery Passport');c.setFont('Helvetica-Bold',20);c.drawString(45,h-55,'Recovery Passport');c.setFont('Helvetica',10);c.drawString(45,h-75,f'Organisation : {org.name}');c.drawString(45,h-90,f'Généré le : {now().strftime("%d/%m/%Y %H:%M UTC")}');c.setFont('Helvetica-Bold',15);c.drawString(45,h-125,f'Indice de préparation : {d["readiness"]} / 100');y=h-160
 for x in d['items']:
  if y<80:c.showPage();y=h-50
  c.setFont('Helvetica-Bold',11);c.drawString(45,y,f'{x["name"]} - score {x["score"]}/100 - état {x["state"]}');y-=15;c.setFont('Helvetica',9);c.drawString(55,y,f'RPO {x["rpo_hours"]} h | âge sauvegarde {x["backup_age_hours"] if x["backup_age_hours"] is not None else "non disponible"} h | restauration {x["restore_result"] or "non testée"}');y-=14
  for a in x['actions'][:3]:c.drawString(65,y,'- '+a);y-=12
 c.setFont('Helvetica-Oblique',8);c.drawString(45,40,'Ce rapport reflète les contrôles et tests documentés. Il ne garantit pas à lui seul la reprise.');c.save();buf.seek(0);return StreamingResponse(buf,media_type='application/pdf',headers={'Content-Disposition':'attachment; filename="recovery-passport.pdf"'})
@app.get('/audit')
def audits(u:User=Depends(current),s:Session=Depends(db)):return s.scalars(select(Audit).where(Audit.org_id==u.org_id).order_by(Audit.at.desc()).limit(100)).all()
