# RecoveryProof V0.4.0

Dashboard détaillé alimenté par PostgreSQL: jauge, KPI, historique, priorités, détail du score, systèmes, agents, tests de restauration et Recovery Passport PDF.

## Démarrage neuf
```bash
make up
```
Ouvrir le port 8080.

## Important pour une base V0.3 existante
Cette archive utilise encore `create_all` pour un laboratoire neuf. Pour conserver une base V0.3, attendre le lot Alembic avant mise à niveau. Ne lancez pas cette version sur la base de production sans migration.

## Score
- sauvegarde dans le RPO: 35 points
- agent actif: 15 points
- restauration réussie depuis moins de 90 jours: 30 points
- RTO respecté: 10 points
- preuve renseignée: 10 points

Aucune donnée historique artificielle n'est créée. Un snapshot est ajouté ou actualisé chaque jour lors de l'ouverture du dashboard.
