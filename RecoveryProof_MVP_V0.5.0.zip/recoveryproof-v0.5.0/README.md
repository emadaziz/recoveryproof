# RecoveryProof V0.5.0

Dashboard détaillé alimenté par PostgreSQL: jauge, KPI, historique, priorités, détail du score, systèmes, agents, tests de restauration et Recovery Passport PDF.

## Démarrage neuf
```bash
make up
```
Ouvrir le port 8080.

## Important pour une base V0.3 existante
Cette archive utilise encore `create_all` pour un laboratoire neuf. Pour conserver une base V0.3, attendre le lot Alembic avant mise à niveau. Ne lancez pas cette version sur la base de production sans migration.

## Score
- sauvegarde dans le RPO: 35 points
- agent actif: 15 points
- restauration réussie depuis moins de 90 jours: 30 points
- RTO respecté: 10 points
- preuve renseignée: 10 points

Aucune donnée historique artificielle n'est créée. Un snapshot est ajouté ou actualisé chaque jour lors de l'ouverture du dashboard.

## Correctif 0.5.0
La création du premier compte exige maintenant la confirmation du mot de passe et applique les mêmes règles côté navigateur et côté API : 12 caractères minimum, une majuscule, une minuscule, un chiffre et un caractère spécial.


## Correctif 0.5.0
Correction de la navigation vers le tableau de bord après une action. Le sélecteur de période ne remplace plus la variable numérique globale par un élément HTML. Les formulaires et boutons utilisent aussi des sélecteurs DOM explicites afin d'éviter les dépendances aux variables globales implicites du navigateur.

## Correctif 0.5.0
- Bouton œil indépendant sur le mot de passe et sa confirmation.
- RPO et RTO stockés en minutes pour accepter des objectifs inférieurs à une heure.
- L'interface permet de saisir une valeur puis de choisir minutes ou heures. Exemples : RPO 15 minutes, RTO 45 minutes, RPO 4 heures.
- Cette version attend une base neuve. Une migration Alembic sera nécessaire pour convertir automatiquement les anciennes colonnes `rpo_hours` et `rto_hours`.

## V0.5 Gestion de crise
Déclaration N1-N4, cellule stratégique/opérationnelle/communication, journal de crise, transitions contrôlées, 10 étapes PCA et 14 étapes PRA. Une installation neuve est requise tant que les migrations Alembic ne sont pas livrées.
