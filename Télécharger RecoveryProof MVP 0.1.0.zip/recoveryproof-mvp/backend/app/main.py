from datetime import datetime, timezone
import os
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from .security import issue_token, token_digest, read_secret

app=FastAPI(title="RecoveryProof API", version="0.1.0", docs_url=None, redoc_url=None)
origins=[x.strip() for x in os.getenv("ALLOWED_ORIGINS","http://localhost:8080").split(",")]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["GET","POST"], allow_headers=["Authorization","Content-Type"], allow_credentials=False)
TOKENS={}
EVENTS=[]
SECRET_PATH=os.getenv("APP_SECRET_FILE","/run/secrets/app_secret")

class TokenRequest(BaseModel):
    name: str=Field(min_length=3,max_length=80)
    scopes: list[str]=Field(default=["checks:write"])
    expires_in_days: int=Field(default=30,ge=1,le=365)
class Check(BaseModel):
    system: str=Field(min_length=1,max_length=120)
    status: str=Field(pattern="^(ok|warning|critical)$")
    age_hours: float=Field(ge=0,le=100000)
    evidence_ref: str|None=Field(default=None,max_length=200)

@app.get("/health")
def health(): return {"status":"ok","time":datetime.now(timezone.utc).isoformat()}
@app.get("/dashboard")
def dashboard():
    return {"readiness":82,"systems":24,"alerts":3,"verifiedRestores":"8 / 12","events":EVENTS[-10:]}
@app.post("/admin/tokens",status_code=201)
def create_token(req:TokenRequest):
    token=issue_token(); digest=token_digest(token,read_secret(SECRET_PATH)); TOKENS[digest]={"name":req.name,"scopes":req.scopes,"revoked":False}
    return {"token":token,"warning":"Copiez ce jeton maintenant. Il ne sera plus affiche."}
@app.post("/v1/checks",status_code=202)
def receive_check(check:Check,authorization:str=Header(default="")):
    if not authorization.startswith("Bearer "): raise HTTPException(401,"Jeton requis")
    digest=token_digest(authorization[7:],read_secret(SECRET_PATH)); meta=TOKENS.get(digest)
    if not meta or meta["revoked"] or "checks:write" not in meta["scopes"]: raise HTTPException(403,"Jeton invalide ou perimetre refuse")
    EVENTS.append({**check.model_dump(),"received_at":datetime.now(timezone.utc).isoformat()})
    return {"accepted":True}
@app.get("/plugins")
def plugins(): return {"plugins":[{"id":"generic-filesystem","version":"0.1.0","status":"available","permissions":["filesystem:read-metadata"]},{"id":"webhook","version":"0.1.0","status":"available","permissions":["checks:write"]}]}
@app.get("/updates")
def updates(): return {"channel":"stable","current":"0.1.0","latest":"0.1.0","signature_required":True,"rollback_supported":True}
