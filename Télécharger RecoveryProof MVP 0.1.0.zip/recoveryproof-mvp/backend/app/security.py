import hashlib, hmac, secrets
from pathlib import Path

def read_secret(path: str) -> bytes:
    return Path(path).read_bytes().strip()

def issue_token() -> str:
    return "rp_" + secrets.token_urlsafe(32)

def token_digest(token: str, key: bytes) -> str:
    return hmac.new(key, token.encode(), hashlib.sha256).hexdigest()

def verify_token(token: str, digest: str, key: bytes) -> bool:
    return hmac.compare_digest(token_digest(token, key), digest)
