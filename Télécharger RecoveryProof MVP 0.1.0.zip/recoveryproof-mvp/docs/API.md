# Connexion des logiciels

## Choix par ordre de preference
1. OAuth 2.1 Client Credentials avec scopes et jetons courts, si le logiciel le supporte.
2. mTLS pour agents administres.
3. Jeton RecoveryProof opaque, limite, expirant et revocable.

## Exemple
Creer un jeton via `POST /api/admin/tokens` depuis une session administrateur. Le jeton n'est affiche qu'une fois. Envoyer ensuite `Authorization: Bearer rp_...` vers `POST /api/v1/checks`. Ne jamais mettre le jeton dans une URL, un fichier partage ou un ticket.

Scopes initiaux: `checks:write`, `systems:read`, `filesystem:read-metadata`. Une integration ne recoit que le strict minimum.
