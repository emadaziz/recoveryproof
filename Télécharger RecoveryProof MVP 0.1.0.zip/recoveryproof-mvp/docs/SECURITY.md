# Securite

- Secrets: fichiers Docker secrets en developpement; coffre de secrets en production. Jamais de secret dans Git, logs, URL, frontend ou rapport.
- Authentification humaine: OIDC/OAuth 2.1 recommande avec MFA/WebAuthn; le MVP n'implemente pas encore la connexion utilisateur.
- Integrations: jetons aleatoires, scopes minimaux, expiration, revocation, rotation et empreinte HMAC uniquement. Preferer mTLS ou OAuth 2.1 Client Credentials lorsqu'un logiciel le supporte.
- Plugins: desactives par defaut, permissions declarees, manifeste signe, execution isolee, aucune sortie reseau implicite.
- Mises a jour: images epinglees par digest en production, SBOM CycloneDX, signature Sigstore/Cosign, migration versionnee et rollback teste.
- Journalisation: identifiant, action, tenant, date et resultat; jamais le contenu de Authorization ni les preuves sensibles.
- Avant production: threat model, OWASP ASVS niveau 2, tests IDOR/multitenant, SAST, SCA, scan Trivy, DAST ZAP, pentest independant.
