# Cadre France / UE (checklist, non-avis juridique)

1. Definir responsable de traitement et sous-traitants; signer un DPA conforme a l'article 28 RGPD.
2. Tenir le registre des traitements, finalites, bases legales, categories, destinataires et durees.
3. Minimiser: ne collecter que metadonnees necessaires; sauvegardes et secrets restent chez le client.
4. Informer les personnes; organiser acces, rectification, effacement, opposition et portabilite selon le contexte.
5. Appliquer l'article 32: mesures proportionnees, disponibilite, restauration et tests reguliers.
6. Prevoir notification des violations: processus interne immediat et evaluation du delai de 72 h pour la CNIL.
7. Hebergement UE par defaut; encadrer et documenter tout transfert hors EEE.
8. Cookies: uniquement cookie de session strictement necessaire par defaut; consentement avant tout traceur non exempt.
9. Retention: parametrable par client, purge automatique, legal hold documente.
10. Realiser une AIPD si le traitement est susceptible d'engendrer un risque eleve.
11. Accessibilite: viser RGAA 4.1.2 / WCAG 2.1 AA pour le service.
12. Ne jamais annoncer « conforme RGPD » sans analyse juridique, dossier de preuves et validation du contexte reel.
