import os
from logging.config import fileConfig
from alembic import context
from sqlalchemy import engine_from_config,pool
from urllib.parse import quote_plus
from app.main import Base
config=context.config
if config.config_file_name:fileConfig(config.config_file_name)
config.set_main_option('sqlalchemy.url',f"postgresql+psycopg://recoveryproof:{quote_plus(os.environ['DB_PASSWORD'])}@db/recoveryproof")
target_metadata=Base.metadata
def offline():
 context.configure(url=config.get_main_option('sqlalchemy.url'),target_metadata=target_metadata,literal_binds=True,compare_type=True);context.run_migrations()
def online():
 with engine_from_config(config.get_section(config.config_ini_section),prefix='sqlalchemy.',poolclass=pool.NullPool).connect() as c:
  context.configure(connection=c,target_metadata=target_metadata,compare_type=True);context.run_migrations()
offline() if context.is_offline_mode() else online()
