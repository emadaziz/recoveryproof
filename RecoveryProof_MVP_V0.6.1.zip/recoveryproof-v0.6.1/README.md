# RecoveryProof V0.6.1 - socle de fiabilisation

Cette version traite les 10 priorités sous forme d'un socle exécutable et vérifiable.

## Livré
1. Pytest pour syntaxe, routes critiques, PCA/PRA, secrets et filtres tenant.
2. Alembic avec baseline et exécution automatique au démarrage.
3. Assertions d'isolation tenant et requêtes `org_id` conservées.
4. Argon2id, sessions courtes et modèle de threat model; passage cookies HttpOnly/MFA reste à faire avant production.
5. `X-Request-ID`, réponses JSON de rate limit et métriques d'erreur.
6. Scripts `backup.sh` et contrôle d'intégrité `restore-test.sh`.
7. CI GitHub Actions: Pytest, compilation, Gitleaks, Trivy, Playwright.
8. Baseline OWASP ASVS L2 et threat model STRIDE.
9. Spécification du connecteur Proxmox Backup Server à permissions minimales; connecteur réseau non activé sans PBS de test.
10. Endpoint Prometheus `/metrics`, profil Prometheus + Grafana.

## Démarrage neuf
```bash
make up
```

## Observabilité
```bash
make observability
```
Prometheus: 9090. Grafana: 3000.

## Sauvegarde
```bash
make backup
./scripts/restore-test.sh backups/recoveryproof-....sql.gz
```

## Limites importantes
La V0.6 n'est pas «100 % sécurisée». Restent obligatoires avant pilote externe: authentification par cookies HttpOnly + CSRF + MFA, tests PostgreSQL multitenant réels, vraie migration depuis chaque ancienne version, SMTP transactionnel, connecteur Proxmox testé, restauration complète automatisée sur base isolée, signature Cosign et pentest indépendant.


## Correctif 0.6.1
Prometheus et Grafana sont replacés sous la clé racine `services`. Dans la V0.6.0, ils étaient incorrectement imbriqués sous `secrets`, ce qui faisait échouer la validation Docker Compose.
