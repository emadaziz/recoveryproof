# Connecteur Proxmox Backup Server - socle V0.6
Permissions minimales prévues: Datastore.Audit et Sys.Audit, sans droit de suppression ni restauration. Données visées: datastore, snapshots, dernier backup, verify state, taille, durée et erreurs. L'implémentation réseau est volontairement désactivée tant que les tests contractuels sur une instance PBS ne sont pas disponibles.
