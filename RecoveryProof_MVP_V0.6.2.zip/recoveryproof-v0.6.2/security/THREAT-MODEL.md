# Threat model STRIDE
Priorités: usurpation de session, IDOR inter-tenant, falsification des contrôles agents, divulgation des preuves, déni de service sur auth/reset, élévation par plugin, compromission de la chaîne de mise à jour. Contrôles: scopes, empreintes HMAC, expirations, org_id systématique, rate limit, audit append-only, images signées, SBOM, rollback et tests IDOR.
