# Baseline
Cible OWASP ASVS 4.0.3 niveau 2. Bloquants release: secret détecté, test tenant rouge, vulnérabilité critique Trivy, migration non testée, sauvegarde absente, image non signée. Pentest indépendant requis avant client payant.
