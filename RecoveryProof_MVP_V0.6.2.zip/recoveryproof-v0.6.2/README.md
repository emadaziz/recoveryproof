# RecoveryProof V0.6.2

Version stabilisée incluant RecoveryProof, PostgreSQL, Alembic, tests Pytest, sauvegardes, Prometheus et Grafana.

## Démarrage
```bash
make up
```
Application: port 8080.

## Observabilité
```bash
make observability
make grafana-password
```
- Prometheus: port 9090
- Grafana: port 3000
- utilisateur Grafana: `admin`
- mot de passe: généré localement dans `secrets/grafana_admin_password.txt`

Le dashboard `RecoveryProof - Supervision plateforme` est provisionné automatiquement avec disponibilité, débit, erreurs 5xx et latence P95. Les volumes `prometheus_data` et `grafana_data` rendent les données persistantes.

## Administration
```bash
make migration-check
make test
make backup
```
`/admin.sh` charge les secrets Docker pour Alembic et Pytest. `/tmp` est un tmpfs de 128 Mio avec `noexec,nosuid,nodev`.

## Correctifs V0.6.2
- Prometheus et Grafana correctement placés dans `services`.
- Persistance Grafana et Prometheus.
- Mot de passe Grafana généré comme secret Docker.
- Dashboard Grafana livré et provisionné.
- Alembic transactionnel avec baseline estampillée automatiquement.
- Script `/admin.sh` pour les commandes d'administration.
- Tests copiés dans l'image API.
- Cache Pytest redirigé vers `/tmp` sécurisé.
