from pathlib import Path
SRC=(Path(__file__).parents[1]/'app/main.py').read_text()
def test_pca_pra_catalogs():
 assert SRC.count("('PCA")>=10;assert SRC.count("('PRA")>=14
def test_critical_routes():
 for route in ['/setup/bootstrap','/auth/login','/systems','/agent/checks','/dashboard','/reports/passport.pdf','/crises','/metrics']:assert route in SRC
