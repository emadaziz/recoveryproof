#!/bin/sh
set -eu
export DB_PASSWORD="$(cat /run/secrets/db_password)"
export APP_SECRET="$(cat /run/secrets/app_secret)"
cd /app
if ! alembic -c alembic.ini current 2>/dev/null | grep -q '0001_baseline'; then
  alembic -c alembic.ini stamp 0001_baseline
fi
alembic -c alembic.ini upgrade head
exec su -s /bin/sh app -c 'exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers'
