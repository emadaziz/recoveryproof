#!/bin/sh
set -eu
export DB_PASSWORD="$(cat /run/secrets/db_password)"
export APP_SECRET="$(cat /run/secrets/app_secret)"
export TMPDIR="${TMPDIR:-/tmp}"
export PYTEST_ADDOPTS="${PYTEST_ADDOPTS:--o cache_dir=/tmp/pytest-cache}"
exec "$@"
