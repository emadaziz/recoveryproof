import os
from pathlib import Path
from logging.config import fileConfig
from urllib.parse import quote_plus
from alembic import context
from sqlalchemy import engine_from_config, pool
config=context.config
if config.config_file_name:fileConfig(config.config_file_name)
def read_secret(env,path):
 value=os.getenv(env)
 if value:return value
 p=Path(path)
 if not p.is_file():raise RuntimeError(f'Secret absent: {env} ou {path}')
 return p.read_text(encoding='utf-8').strip()
db_password=read_secret('DB_PASSWORD','/run/secrets/db_password')
app_secret=read_secret('APP_SECRET','/run/secrets/app_secret')
os.environ['DB_PASSWORD']=db_password;os.environ['APP_SECRET']=app_secret
config.set_main_option('sqlalchemy.url',f'postgresql+psycopg://recoveryproof:{quote_plus(db_password)}@db/recoveryproof')
from app.main import Base
target_metadata=Base.metadata
def run_migrations_offline():
 context.configure(url=config.get_main_option('sqlalchemy.url'),target_metadata=target_metadata,literal_binds=True,compare_type=True)
 with context.begin_transaction():context.run_migrations()
def run_migrations_online():
 connectable=engine_from_config(config.get_section(config.config_ini_section),prefix='sqlalchemy.',poolclass=pool.NullPool)
 with connectable.connect() as connection:
  context.configure(connection=connection,target_metadata=target_metadata,compare_type=True,transaction_per_migration=True)
  with context.begin_transaction():context.run_migrations()
run_migrations_offline() if context.is_offline_mode() else run_migrations_online()
