#!/bin/sh
set -eu
umask 077
OUT=${BACKUP_DIR:-./backups};mkdir -p "$OUT";FILE="$OUT/recoveryproof-$(date -u +%Y%m%dT%H%M%SZ).sql.gz"
docker compose exec -T db pg_dump -U recoveryproof recoveryproof | gzip -9 > "$FILE"
test -s "$FILE";sha256sum "$FILE" > "$FILE.sha256";echo "$FILE"
