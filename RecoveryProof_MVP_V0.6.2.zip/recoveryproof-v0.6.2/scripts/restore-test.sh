#!/bin/sh
set -eu
FILE=${1:?Usage: restore-test.sh backup.sql.gz}
gzip -t "$FILE";sha256sum -c "$FILE.sha256";echo "Archive et empreinte valides. Effectuer la restauration complète sur une base isolée avant production."
