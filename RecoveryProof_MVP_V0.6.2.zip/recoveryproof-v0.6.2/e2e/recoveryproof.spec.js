const { test, expect } = require('@playwright/test');
test('initialisation and dashboard', async ({ page }) => {
 await page.goto(process.env.BASE_URL || 'http://localhost:8080');
 await expect(page.locator('body')).toContainText(/Initialiser RecoveryProof|Connexion/);
});
