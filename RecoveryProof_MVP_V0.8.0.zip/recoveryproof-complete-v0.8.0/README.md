# RecoveryProof Complete V0.8.0

Application consolidée avec dashboard, systèmes, RPO/RTO en minutes, agents, restaurations colorées, Recovery Passport, gestion de crise, 10 étapes PCA, 14 étapes PRA, sessions HttpOnly, CSRF, MFA TOTP, reset de mot de passe via Mailpit, Prometheus et Grafana.

## Démarrage
```bash
make up
make mail
make observability
```
Ports : 8080 RecoveryProof, 8025 Mailpit, 9090 Prometheus, 3000 Grafana.

## Grafana
Utilisateur `admin`. Mot de passe : `make grafana-password`. Dashboard provisionné avec 13 panneaux.

## Remarque Docker Compose
Le montage temporaire utilise la forme compatible Killercoda : `"/tmp:size=128m,mode=1777"`.
