#!/bin/sh
set -eu
export DB_PASSWORD="$(cat /run/secrets/db_password)"
export APP_SECRET="$(cat /run/secrets/app_secret)"
export TMPDIR=/tmp
exec "$@"
