#!/bin/sh
set -eu
export DB_PASSWORD="$(cat /run/secrets/db_password)"
export APP_SECRET="$(cat /run/secrets/app_secret)"
exec su -s /bin/sh app -c 'uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers'
