#!/bin/sh
set -eu
mkdir -p backups
F="backups/recoveryproof-$(date -u +%Y%m%dT%H%M%SZ).sql.gz"
docker compose exec -T db pg_dump -U recoveryproof recoveryproof | gzip -9 > "$F"
sha256sum "$F" > "$F.sha256"
echo "$F"
