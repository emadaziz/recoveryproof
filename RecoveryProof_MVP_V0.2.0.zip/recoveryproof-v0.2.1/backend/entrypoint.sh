#!/bin/sh
set -eu
umask 077
install -o app -g app -m 0400 /run/secrets/db_password /tmp/db_password
install -o app -g app -m 0400 /run/secrets/app_secret /tmp/app_secret
export DB_PASSWORD_FILE=/tmp/db_password APP_SECRET_FILE=/tmp/app_secret
exec su -s /bin/sh app -c 'exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers'
