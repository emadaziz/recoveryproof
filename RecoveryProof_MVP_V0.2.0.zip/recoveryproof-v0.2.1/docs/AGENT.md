# Agent RecoveryProof

Oui, un agent doit être exécuté sur chaque machine cible ou, de préférence, sur une passerelle de sauvegarde ayant un accès en lecture seule aux dépôts de plusieurs machines. Il ne lit pas les mots de passe et ne transmet pas les fichiers: seulement date du fichier le plus récent, nombre de fichiers et taille totale.

## Exécution ponctuelle
```bash
docker build -t recoveryproof-agent:0.2.1 ./agent
docker run --rm --read-only --cap-drop ALL --security-opt no-new-privileges \
  -e RP_API_URL=http://ADRESSE_RECOVERYPROOF:8080 \
  -e RP_AGENT_TOKEN='JETON_AFFICHÉ_UNE_FOIS' \
  -e RP_SYSTEM_ID=1 \
  -e RP_WATCH_PATH=/data \
  -v /chemin/sauvegardes:/data:ro \
  recoveryproof-agent:0.2.1
```

## Recommandation d'architecture
- 1 agent par site ou dépôt, plutôt qu'un agent par serveur, si la passerelle voit les sauvegardes en lecture seule.
- Aucun port entrant sur la machine cible. Connexion HTTPS sortante uniquement.
- Jeton par agent, expiration courte, révocable dans l'interface.
- En production, utiliser un ordonnanceur systemd ou Kubernetes CronJob toutes les 15 à 60 minutes selon le RPO.
