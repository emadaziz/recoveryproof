# RecoveryProof V0.3.0

Fonctions: authentification, systèmes, agents, contrôles, tableau de bord PostgreSQL, plugins activables, paramètres, vérification des mises à jour et réinitialisation de mot de passe par e-mail.

## Démarrage
```bash
make up
```
- Application: port 8080
- Boîte e-mail de test Mailpit: port 8025

## Test du mot de passe oublié
1. Ouvrir RecoveryProof sur le port 8080.
2. Cliquer **Mot de passe oublié**.
3. Entrer l'e-mail du compte.
4. Ouvrir le port 8025 dans Killercoda pour afficher Mailpit.
5. Ouvrir l'e-mail et son lien. Le lien expire après 15 minutes et ne fonctionne qu'une fois.

## Production SMTP
Retirer Mailpit et configurer `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_TLS=true`, `SMTP_FROM` et `PUBLIC_URL=https://votre-domaine`. Le mot de passe SMTP doit provenir d'un coffre de secrets, jamais du dépôt Git.

## Mise à jour
Le bouton vérifie l'état et le canal. L'installation automatique reste volontairement désactivée tant que la chaîne de versions signées et le rollback ne sont pas en place.
