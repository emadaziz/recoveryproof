# Sécurité
- Argon2id pour les mots de passe.
- Jetons de réinitialisation aléatoires, empreinte HMAC uniquement, expiration 15 minutes, usage unique.
- Réponse identique pour une adresse existante ou inconnue afin de limiter l'énumération de comptes.
- Limite de 3 demandes de réinitialisation par heure et 5 validations par heure.
- Mailpit est uniquement destiné au laboratoire. En production utiliser un SMTP authentifié avec TLS, SPF, DKIM et DMARC.
- Plugins désactivés par défaut. Cette version active leur état; l'exécution isolée des binaires de plugins reste hors périmètre.
- Mise à jour automatique désactivée. Exiger signatures Cosign, SBOM CycloneDX, sauvegarde et rollback avant activation.
