import os,secrets,hashlib,hmac,time,smtplib,ssl
from datetime import datetime,timezone,timedelta
from email.message import EmailMessage
from urllib.parse import quote_plus
import jwt
from argon2 import PasswordHasher
from fastapi import FastAPI,Depends,HTTPException,Request,Header,Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel,Field
from sqlalchemy import create_engine,String,Integer,DateTime,ForeignKey,Boolean,Text,select,func
from sqlalchemy.orm import DeclarativeBase,Mapped,mapped_column,sessionmaker,Session
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
UTC=timezone.utc
def now():return datetime.now(UTC)
DB_PASSWORD=os.environ['DB_PASSWORD'];SECRET=os.environ['APP_SECRET']
engine=create_engine(f'postgresql+psycopg://recoveryproof:{quote_plus(DB_PASSWORD)}@db/recoveryproof',pool_pre_ping=True)
SessionLocal=sessionmaker(engine,expire_on_commit=False);ph=PasswordHasher(time_cost=3,memory_cost=65536,parallelism=2)
oauth=OAuth2PasswordBearer(tokenUrl='/api/auth/login');limiter=Limiter(key_func=get_remote_address)
class Base(DeclarativeBase):pass
class Org(Base):
 __tablename__='orgs';id:Mapped[int]=mapped_column(primary_key=True);name:Mapped[str]=mapped_column(String(120));created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class User(Base):
 __tablename__='users';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(ForeignKey('orgs.id'));email:Mapped[str]=mapped_column(String(254),unique=True,index=True);password_hash:Mapped[str]=mapped_column(Text);role:Mapped[str]=mapped_column(String(30),default='admin');active:Mapped[bool]=mapped_column(Boolean,default=True)
class System(Base):
 __tablename__='systems';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);name:Mapped[str]=mapped_column(String(120));criticality:Mapped[str]=mapped_column(String(20));rpo_hours:Mapped[int]=mapped_column(Integer);rto_hours:Mapped[int]=mapped_column(Integer);owner:Mapped[str|None]=mapped_column(String(120),nullable=True)
class Agent(Base):
 __tablename__='agents';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);name:Mapped[str]=mapped_column(String(120));token_digest:Mapped[str]=mapped_column(String(64),unique=True);revoked:Mapped[bool]=mapped_column(Boolean,default=False);expires_at:Mapped[datetime]=mapped_column(DateTime(timezone=True));last_seen:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)
class Check(Base):
 __tablename__='checks';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);system_id:Mapped[int]=mapped_column(index=True);agent_id:Mapped[int]=mapped_column();status:Mapped[str]=mapped_column(String(20));newest_file_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True);file_count:Mapped[int]=mapped_column(Integer);total_bytes:Mapped[int]=mapped_column(Integer);received_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class ResetToken(Base):
 __tablename__='reset_tokens';id:Mapped[int]=mapped_column(primary_key=True);user_id:Mapped[int]=mapped_column(ForeignKey('users.id'),index=True);digest:Mapped[str]=mapped_column(String(64),unique=True,index=True);expires_at:Mapped[datetime]=mapped_column(DateTime(timezone=True));used_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True);created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Plugin(Base):
 __tablename__='plugins';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);code:Mapped[str]=mapped_column(String(80));name:Mapped[str]=mapped_column(String(120));enabled:Mapped[bool]=mapped_column(Boolean,default=False);version:Mapped[str]=mapped_column(String(30),default='1.0.0')
class Audit(Base):
 __tablename__='audit';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);actor:Mapped[str]=mapped_column(String(254));action:Mapped[str]=mapped_column(String(100));resource:Mapped[str]=mapped_column(String(150));at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Bootstrap(BaseModel):org_name:str=Field(min_length=2,max_length=120);email:str=Field(min_length=5,max_length=254);password:str=Field(min_length=12,max_length=200)
class Login(BaseModel):email:str;password:str
class Forgot(BaseModel):email:str
class Reset(BaseModel):token:str=Field(min_length=30,max_length=300);password:str=Field(min_length=12,max_length=200)
class SystemIn(BaseModel):name:str=Field(min_length=2,max_length=120);criticality:str=Field(pattern='^(low|medium|high|critical)$');rpo_hours:int=Field(ge=1,le=8760);rto_hours:int=Field(ge=1,le=8760);owner:str|None=None
class AgentIn(BaseModel):name:str=Field(min_length=2,max_length=120);expires_days:int=Field(default=30,ge=1,le=365)
class CheckIn(BaseModel):system_id:int;status:str=Field(pattern='^(ok|warning|critical)$');newest_file_at:datetime|None=None;file_count:int=Field(ge=0);total_bytes:int=Field(ge=0)
class PluginToggle(BaseModel):enabled:bool
def db():
 s=SessionLocal()
 try:yield s
 finally:s.close()
def dg(v):return hmac.new(SECRET.encode(),v.encode(),hashlib.sha256).hexdigest()
def session_token(u):return jwt.encode({'sub':str(u.id),'org':u.org_id,'exp':now()+timedelta(minutes=30)},SECRET,algorithm='HS256')
def current(token:str=Depends(oauth),s:Session=Depends(db)):
 try:d=jwt.decode(token,SECRET,algorithms=['HS256']);u=s.get(User,int(d['sub']))
 except Exception:raise HTTPException(401,'Session invalide ou expirée')
 if not u or not u.active:raise HTTPException(401,'Compte inactif')
 return u
def audit(s,u,action,res):s.add(Audit(org_id=u.org_id,actor=u.email,action=action,resource=res))
def org_obj(s,model,i,org):
 o=s.scalar(select(model).where(model.id==i,model.org_id==org))
 if not o:raise HTTPException(404,'Ressource introuvable')
 return o
def send_reset(email,link):
 m=EmailMessage();m['Subject']='Réinitialisation de votre mot de passe RecoveryProof';m['From']=os.getenv('SMTP_FROM','RecoveryProof <no-reply@recoveryproof.local>');m['To']=email
 m.set_content(f'''Une réinitialisation de mot de passe a été demandée pour votre compte RecoveryProof.\n\nLien valable 15 minutes et utilisable une seule fois :\n{link}\n\nSi vous n'êtes pas à l'origine de cette demande, ignorez cet e-mail.''')
 host=os.getenv('SMTP_HOST','mailpit');port=int(os.getenv('SMTP_PORT','1025'));user=os.getenv('SMTP_USER');pwd=os.getenv('SMTP_PASSWORD');tls=os.getenv('SMTP_TLS','false').lower()=='true'
 with smtplib.SMTP(host,port,timeout=10) as smtp:
  if tls:smtp.starttls(context=ssl.create_default_context())
  if user:smtp.login(user,pwd or '')
  smtp.send_message(m)
app=FastAPI(title='RecoveryProof API',version='0.3.0',docs_url=None,redoc_url=None);app.state.limiter=limiter;app.add_middleware(SlowAPIMiddleware);app.add_middleware(CORSMiddleware,allow_origins=['http://localhost:8080'],allow_methods=['GET','POST','DELETE'],allow_headers=['Authorization','Content-Type'])
@app.exception_handler(RateLimitExceeded)
async def limited(request,exc):
 from fastapi.responses import JSONResponse
 return JSONResponse({'detail':'Trop de tentatives. Réessayez dans une minute.'},429)
@app.on_event('startup')
def startup():
 Base.metadata.create_all(engine)
 with SessionLocal() as s:
  if not s.scalar(select(func.count(Plugin.id))):
   s.add_all([Plugin(org_id=1,code='filesystem',name='Generic Filesystem'),Plugin(org_id=1,code='webhook',name='Webhook entrant'),Plugin(org_id=1,code='proxmox',name='Proxmox')]);s.commit()
@app.get('/health')
def health():return {'status':'ok','version':'0.3.0','time':now()}
@app.get('/setup/status')
def setup_status(s:Session=Depends(db)):return {'required':(s.scalar(select(func.count(User.id))) or 0)==0}
@app.post('/setup/bootstrap',status_code=201)
@limiter.limit('3/minute')
def bootstrap(request:Request,x:Bootstrap=Body(...),s:Session=Depends(db)):
 if s.scalar(select(func.count(User.id))):raise HTTPException(409,'Initialisation déjà effectuée')
 o=Org(name=x.org_name);s.add(o);s.flush();u=User(org_id=o.id,email=x.email.lower(),password_hash=ph.hash(x.password));s.add(u);s.flush();audit(s,u,'bootstrap','organization');s.commit();return {'access_token':session_token(u),'token_type':'bearer'}
@app.post('/auth/login')
@limiter.limit('5/minute')
def login(request:Request,x:Login=Body(...),s:Session=Depends(db)):
 u=s.scalar(select(User).where(User.email==x.email.lower()))
 try:ok=bool(u and ph.verify(u.password_hash,x.password))
 except Exception:ok=False
 if not ok:time.sleep(.4);raise HTTPException(401,'Identifiants invalides')
 return {'access_token':session_token(u),'token_type':'bearer'}
@app.post('/auth/forgot-password',status_code=202)
@limiter.limit('3/hour')
def forgot(request:Request,x:Forgot=Body(...),s:Session=Depends(db)):
 u=s.scalar(select(User).where(User.email==x.email.lower(),User.active==True))
 if u:
  raw=secrets.token_urlsafe(48);s.add(ResetToken(user_id=u.id,digest=dg(raw),expires_at=now()+timedelta(minutes=15)));s.commit()
  base=os.getenv('PUBLIC_URL') or f"{request.url.scheme}://{request.headers.get('host','localhost:8080')}";send_reset(u.email,f'{base.rstrip('/')}/?reset={raw}')
 return {'message':'Si cette adresse existe, un e-mail a été envoyé.'}
@app.post('/auth/reset-password')
@limiter.limit('5/hour')
def reset_password(request:Request,x:Reset=Body(...),s:Session=Depends(db)):
 r=s.scalar(select(ResetToken).where(ResetToken.digest==dg(x.token),ResetToken.used_at==None,ResetToken.expires_at>now()))
 if not r:raise HTTPException(400,'Lien invalide, expiré ou déjà utilisé')
 u=s.get(User,r.user_id);u.password_hash=ph.hash(x.password);r.used_at=now();s.query(ResetToken).filter(ResetToken.user_id==u.id,ResetToken.id!=r.id).update({'used_at':now()});audit(s,u,'password.reset',str(u.id));s.commit();return {'message':'Mot de passe remplacé.'}
@app.get('/me')
def me(u:User=Depends(current),s:Session=Depends(db)):return {'email':u.email,'role':u.role,'organization':s.get(Org,u.org_id).name}
@app.get('/systems')
def systems(u:User=Depends(current),s:Session=Depends(db)):return s.scalars(select(System).where(System.org_id==u.org_id)).all()
@app.post('/systems',status_code=201)
def add_system(x:SystemIn=Body(...),u:User=Depends(current),s:Session=Depends(db)):
 o=System(org_id=u.org_id,**x.model_dump());s.add(o);s.flush();audit(s,u,'system.create',str(o.id));s.commit();s.refresh(o);return o
@app.delete('/systems/{i}',status_code=204)
def del_system(i:int,u:User=Depends(current),s:Session=Depends(db)):
 o=org_obj(s,System,i,u.org_id);s.delete(o);s.commit()
@app.get('/agents')
def agents(u:User=Depends(current),s:Session=Depends(db)):return [{'id':a.id,'name':a.name,'revoked':a.revoked,'expires_at':a.expires_at,'last_seen':a.last_seen} for a in s.scalars(select(Agent).where(Agent.org_id==u.org_id))]
@app.post('/agents',status_code=201)
def add_agent(x:AgentIn=Body(...),u:User=Depends(current),s:Session=Depends(db)):
 raw='rpa_'+secrets.token_urlsafe(32);a=Agent(org_id=u.org_id,name=x.name,token_digest=dg(raw),expires_at=now()+timedelta(days=x.expires_days));s.add(a);s.commit();return {'token':raw,'warning':'Copiez ce jeton maintenant.'}
def agent_auth(authorization:str=Header(default=''),s:Session=Depends(db)):
 if not authorization.startswith('Bearer rpa_'):raise HTTPException(401,'Jeton requis')
 a=s.scalar(select(Agent).where(Agent.token_digest==dg(authorization[7:])))
 if not a or a.revoked or a.expires_at<now():raise HTTPException(403,'Jeton invalide')
 return a
@app.post('/agent/checks',status_code=202)
def check(x:CheckIn=Body(...),a:Agent=Depends(agent_auth),s:Session=Depends(db)):
 org_obj(s,System,x.system_id,a.org_id);a.last_seen=now();s.add(Check(org_id=a.org_id,agent_id=a.id,**x.model_dump()));s.commit();return {'accepted':True}
@app.get('/dashboard')
def dashboard(u:User=Depends(current),s:Session=Depends(db)):
 ss=s.scalars(select(System).where(System.org_id==u.org_id)).all();items=[];protected=0
 for x in ss:
  c=s.scalar(select(Check).where(Check.org_id==u.org_id,Check.system_id==x.id).order_by(Check.received_at.desc()));age=(now()-c.newest_file_at).total_seconds()/3600 if c and c.newest_file_at else None;state='ok' if age is not None and age<=x.rpo_hours and c.status=='ok' else 'alert';protected+=state=='ok';items.append({'id':x.id,'name':x.name,'rpo_hours':x.rpo_hours,'backup_age_hours':round(age,1) if age is not None else None,'state':state})
 return {'readiness':round(protected/len(ss)*100) if ss else 0,'systems_total':len(ss),'systems_protected':protected,'alerts':len(ss)-protected,'items':items}
@app.get('/plugins')
def plugins(u:User=Depends(current),s:Session=Depends(db)):
 rows=s.scalars(select(Plugin).where((Plugin.org_id==u.org_id)|(Plugin.org_id==1))).all();return rows
@app.post('/plugins/{i}')
def toggle_plugin(i:int,x:PluginToggle=Body(...),u:User=Depends(current),s:Session=Depends(db)):
 p=s.get(Plugin,i)
 if not p:raise HTTPException(404,'Plugin introuvable')
 p.enabled=x.enabled;p.org_id=u.org_id;audit(s,u,'plugin.toggle',p.code);s.commit();return {'enabled':p.enabled}
@app.get('/settings')
def settings(u:User=Depends(current)):return {'session_minutes':30,'smtp_configured':bool(os.getenv('SMTP_HOST')),'update_channel':os.getenv('UPDATE_CHANNEL','stable'),'current_version':'0.3.0'}
@app.get('/updates/check')
def updates(u:User=Depends(current)):return {'current':'0.3.0','channel':os.getenv('UPDATE_CHANNEL','stable'),'status':'up_to_date','signed_updates_required':True,'automatic_install':False}
@app.get('/audit')
def audits(u:User=Depends(current),s:Session=Depends(db)):return s.scalars(select(Audit).where(Audit.org_id==u.org_id).order_by(Audit.at.desc()).limit(100)).all()
