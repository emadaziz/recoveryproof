import os,json,urllib.request
from pathlib import Path
from datetime import datetime,timezone
api=os.environ['RP_API_URL'].rstrip('/');token=os.environ['RP_AGENT_TOKEN'];sid=int(os.environ['RP_SYSTEM_ID']);root=Path(os.getenv('RP_WATCH_PATH','/data'))
files=[p for p in root.rglob('*') if p.is_file()];newest=max((p.stat().st_mtime for p in files),default=None)
data=json.dumps({'system_id':sid,'status':'ok' if files else 'warning','newest_file_at':datetime.fromtimestamp(newest,timezone.utc).isoformat() if newest else None,'file_count':len(files),'total_bytes':sum(p.stat().st_size for p in files)}).encode()
req=urllib.request.Request(api+'/api/agent/checks',data=data,headers={'Content-Type':'application/json','Authorization':'Bearer '+token},method='POST')
print(urllib.request.urlopen(req,timeout=20).read().decode())
