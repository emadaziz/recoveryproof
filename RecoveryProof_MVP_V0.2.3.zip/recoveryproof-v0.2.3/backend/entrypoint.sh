#!/bin/sh
set -eu
# Docker mounts secrets read-only for root. Read them once, export them only
# to the API process, then drop privileges to UID 10001. No secret is copied
# to disk, printed, or included in the image.
export DB_PASSWORD="$(cat /run/secrets/db_password)"
export APP_SECRET="$(cat /run/secrets/app_secret)"
exec su -s /bin/sh app -c 'exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers'
