# Correctif RecoveryProof V0.7.2

Paquet de mise à niveau de la V0.7.0 complète vers la V0.7.2.

Depuis la racine de `recoveryproof-v0.7.0`, exécuter le script `upgrade-to-v0.7.2.sh` avec son chemin, puis lancer `make up` et `make observability`.

Le dashboard Grafana provisionné contient neuf panneaux : disponibilité instantanée, disponibilité 6 h, taux 5xx, connexions refusées, débit, latence P95, statuts HTTP, requêtes limitées et erreurs 5xx.
