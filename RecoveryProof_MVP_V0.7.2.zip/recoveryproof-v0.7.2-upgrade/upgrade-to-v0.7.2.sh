#!/bin/sh
set -eu
if [ ! -f compose.yaml ] || [ ! -f Makefile ]; then echo "Exécutez ce script depuis la racine de recoveryproof-v0.7.0" >&2; exit 1; fi
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p deployment/grafana/dashboards
cp "$SCRIPT_DIR/deployment/grafana/dashboards/recoveryproof-platform.json" deployment/grafana/dashboards/recoveryproof-platform.json
python3 - <<'PY'
from pathlib import Path
p=Path('Makefile');s=p.read_text();old='observability: init-secrets\n\tdocker compose --profile observability up -d prometheus grafana';new='observability: init-secrets\n\tchmod 644 secrets/grafana_admin_password.txt\n\tdocker compose --profile observability up -d prometheus grafana';s=s.replace(old,new).replace('recoveryproof-agent:0.7.0','recoveryproof-agent:0.7.2');p.write_text(s)
p=Path('backend/app/main.py');s=p.read_text().replace("version='0.7.0'","version='0.7.2'").replace("'version':'0.7.0'","'version':'0.7.2'").replace("'current_version':'0.7.0'","'current_version':'0.7.2'").replace("'current':'0.7.0','latest':'0.7.0'","'current':'0.7.2','latest':'0.7.2'");p.write_text(s)
for name in ['frontend/public/app.js','README.md','docs/AUTHENTICATION-V0.7.md']:
 p=Path(name)
 if p.exists():p.write_text(p.read_text().replace('0.7.0','0.7.2'))
PY
python3 -m json.tool deployment/grafana/dashboards/recoveryproof-platform.json >/dev/null
node --check frontend/public/app.js
python3 -m py_compile backend/app/main.py
echo "Mise à niveau V0.7.2 appliquée. Exécutez: make up && make observability"
