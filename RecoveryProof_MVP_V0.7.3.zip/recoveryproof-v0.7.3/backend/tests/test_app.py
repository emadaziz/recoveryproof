from pathlib import Path
S=(Path(__file__).parents[1]/'app/main.py').read_text()
def test_security():
 assert 'httponly=True' in S and 'samesite=' in S and 'csrf' in S and 'pyotp.TOTP' in S
def test_tenant():assert 'System.org_id==u.org_id' in S
def test_metrics():assert 'recoveryproof_http_requests_total' in S
def test_version():assert "'version':'0.7.3'" in S
