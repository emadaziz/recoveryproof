import os,secrets,hashlib,hmac,time,base64,uuid
from datetime import datetime,timezone,timedelta
from cryptography.fernet import Fernet
import pyotp
from argon2 import PasswordHasher
from fastapi import FastAPI,Depends,HTTPException,Request,Response,Body,Header
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel,Field,field_validator
from sqlalchemy import create_engine,String,Integer,DateTime,ForeignKey,Boolean,Text,select,func
from sqlalchemy.orm import DeclarativeBase,Mapped,mapped_column,sessionmaker,Session
from prometheus_client import Counter,Histogram,generate_latest,CONTENT_TYPE_LATEST
from fastapi.responses import Response as FastResponse
UTC=timezone.utc
def now():return datetime.now(UTC)
DB_PASSWORD=os.environ['DB_PASSWORD'];SECRET=os.environ['APP_SECRET'];COOKIE_SECURE=os.getenv('COOKIE_SECURE','false').lower()=='true'
engine=create_engine(f'postgresql+psycopg://recoveryproof:{DB_PASSWORD}@db/recoveryproof',pool_pre_ping=True);SessionLocal=sessionmaker(engine,expire_on_commit=False);ph=PasswordHasher();FERNET=Fernet(base64.urlsafe_b64encode(hashlib.sha256(SECRET.encode()).digest()))
class Base(DeclarativeBase):pass
class Org(Base):__tablename__='orgs';id:Mapped[int]=mapped_column(primary_key=True);name:Mapped[str]=mapped_column(String(120))
class User(Base):__tablename__='users';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(ForeignKey('orgs.id'));email:Mapped[str]=mapped_column(String(254),unique=True);password_hash:Mapped[str]=mapped_column(Text);active:Mapped[bool]=mapped_column(Boolean,default=True)
class WebSession(Base):__tablename__='web_sessions';id:Mapped[int]=mapped_column(primary_key=True);user_id:Mapped[int]=mapped_column(ForeignKey('users.id'));digest:Mapped[str]=mapped_column(String(64),unique=True);csrf_digest:Mapped[str]=mapped_column(String(64));expires_at:Mapped[datetime]=mapped_column(DateTime(timezone=True));revoked:Mapped[bool]=mapped_column(Boolean,default=False)
class MFA(Base):__tablename__='mfa';id:Mapped[int]=mapped_column(primary_key=True);user_id:Mapped[int]=mapped_column(ForeignKey('users.id'),unique=True);secret:Mapped[str]=mapped_column(Text);enabled:Mapped[bool]=mapped_column(Boolean,default=False)
class System(Base):__tablename__='systems';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);name:Mapped[str]=mapped_column(String(120));criticality:Mapped[str]=mapped_column(String(20));rpo_minutes:Mapped[int]=mapped_column(Integer);rto_minutes:Mapped[int]=mapped_column(Integer);owner:Mapped[str|None]=mapped_column(String(120),nullable=True)
class Restore(Base):__tablename__='restores';id:Mapped[int]=mapped_column(primary_key=True);org_id:Mapped[int]=mapped_column(index=True);system_id:Mapped[int]=mapped_column(index=True);result:Mapped[str]=mapped_column(String(20));duration_minutes:Mapped[int]=mapped_column(Integer);tested_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Bootstrap(BaseModel):
 org_name:str=Field(min_length=2);email:str;password:str=Field(min_length=12)
 @field_validator('password')
 @classmethod
 def strong(cls,v):
  if not all([any(c.isupper() for c in v),any(c.islower() for c in v),any(c.isdigit() for c in v),any(not c.isalnum() for c in v)]):raise ValueError('Majuscule, minuscule, chiffre et caractère spécial requis')
  return v
class Login(BaseModel):email:str;password:str;totp_code:str|None=None
class SystemIn(BaseModel):name:str;criticality:str=Field(pattern='^(low|medium|high|critical)$');rpo_minutes:int=Field(ge=1);rto_minutes:int=Field(ge=1);owner:str|None=None
class RestoreIn(BaseModel):system_id:int;result:str=Field(pattern='^(success|partial|failed)$');duration_minutes:int=Field(ge=0)
class MFAEnable(BaseModel):code:str=Field(pattern='^[0-9]{6}$')
def db():
 s=SessionLocal()
 try:yield s
 finally:s.close()
def dg(x):return hmac.new(SECRET.encode(),x.encode(),hashlib.sha256).hexdigest()
def issue(response,u,s):
 raw=secrets.token_urlsafe(48);csrf=secrets.token_urlsafe(32);s.add(WebSession(user_id=u.id,digest=dg(raw),csrf_digest=dg(csrf),expires_at=now()+timedelta(minutes=30)));s.commit();response.set_cookie('rp_session',raw,httponly=True,samesite='strict',secure=COOKIE_SECURE,max_age=1800);response.set_cookie('rp_csrf',csrf,httponly=False,samesite='strict',secure=COOKIE_SECURE,max_age=1800);return {'authenticated':True}
def current(request:Request,s:Session=Depends(db)):
 raw=request.cookies.get('rp_session');rec=s.scalar(select(WebSession).where(WebSession.digest==dg(raw or ''),WebSession.revoked==False,WebSession.expires_at>now()))
 if not rec:raise HTTPException(401,'Session invalide ou expirée')
 return s.get(User,rec.user_id)
def csrf(request:Request,s:Session=Depends(db)):
 raw=request.cookies.get('rp_session');c=request.cookies.get('rp_csrf');h=request.headers.get('x-csrf-token');rec=s.scalar(select(WebSession).where(WebSession.digest==dg(raw or ''),WebSession.revoked==False))
 if not rec or not c or not h or not hmac.compare_digest(c,h) or not hmac.compare_digest(rec.csrf_digest,dg(c)):raise HTTPException(403,'CSRF invalide')
REQ=Counter('recoveryproof_http_requests_total','Requests',['method','path','status']);LAT=Histogram('recoveryproof_http_request_seconds','Latency',['method','path'])
app=FastAPI(title='RecoveryProof',version='0.7.3',docs_url=None);app.add_middleware(CORSMiddleware,allow_origins=['http://localhost:8080'],allow_credentials=True,allow_methods=['*'],allow_headers=['Content-Type','X-CSRF-Token'])
@app.middleware('http')
async def metrics(request,call_next):
 st=time.monotonic();r=await call_next(request);REQ.labels(request.method,request.url.path,str(r.status_code)).inc();LAT.labels(request.method,request.url.path).observe(time.monotonic()-st);r.headers['X-Request-ID']='req_'+uuid.uuid4().hex[:16];return r
@app.on_event('startup')
def startup():Base.metadata.create_all(engine)
@app.get('/health')
def health():return {'status':'ok','version':'0.7.3','time':now()}
@app.get('/metrics',include_in_schema=False)
def met():return FastResponse(generate_latest(),media_type=CONTENT_TYPE_LATEST)
@app.get('/setup/status')
def setup(s:Session=Depends(db)):return {'required':not bool(s.scalar(select(func.count(User.id))))}
@app.post('/setup/bootstrap',status_code=201)
def bootstrap(response:Response,x:Bootstrap=Body(...),s:Session=Depends(db)):
 if s.scalar(select(func.count(User.id))):raise HTTPException(409,'Déjà initialisé')
 o=Org(name=x.org_name);s.add(o);s.flush();u=User(org_id=o.id,email=x.email.lower(),password_hash=ph.hash(x.password));s.add(u);s.flush();return issue(response,u,s)
@app.post('/auth/login')
def login(response:Response,x:Login=Body(...),s:Session=Depends(db)):
 u=s.scalar(select(User).where(User.email==x.email.lower()))
 try:ok=bool(u and ph.verify(u.password_hash,x.password))
 except:ok=False
 if not ok:raise HTTPException(401,'Identifiants invalides')
 m=s.scalar(select(MFA).where(MFA.user_id==u.id,MFA.enabled==True))
 if m:
  if not x.totp_code:raise HTTPException(428,'Code MFA requis')
  if not pyotp.TOTP(FERNET.decrypt(m.secret.encode()).decode()).verify(x.totp_code,valid_window=1):raise HTTPException(401,'Code MFA invalide')
 return issue(response,u,s)
@app.post('/auth/logout',status_code=204)
def logout(request:Request,response:Response,s:Session=Depends(db),ok=Depends(csrf)):
 raw=request.cookies.get('rp_session');rec=s.scalar(select(WebSession).where(WebSession.digest==dg(raw or '')))
 if rec:rec.revoked=True;s.commit()
 response.delete_cookie('rp_session');response.delete_cookie('rp_csrf')
@app.get('/me')
def me(u:User=Depends(current),s:Session=Depends(db)):return {'email':u.email,'organization':s.get(Org,u.org_id).name}
@app.get('/systems')
def systems(u:User=Depends(current),s:Session=Depends(db)):
 out=[]
 for x in s.scalars(select(System).where(System.org_id==u.org_id)):
  r=s.scalar(select(Restore).where(Restore.org_id==u.org_id,Restore.system_id==x.id).order_by(Restore.tested_at.desc()));score=40 if r and r.result=='success' else 0;out.append({'id':x.id,'name':x.name,'criticality':x.criticality,'rpo_minutes':x.rpo_minutes,'rto_minutes':x.rto_minutes,'owner':x.owner,'restore_result':r.result if r else None,'score':score,'state':'warning' if score else 'critical'})
 return out
@app.post('/systems',status_code=201)
def add_system(x:SystemIn=Body(...),u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):
 o=System(org_id=u.org_id,**x.model_dump());s.add(o);s.commit();s.refresh(o);return o
@app.post('/restore-tests',status_code=201)
def restore(x:RestoreIn=Body(...),u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):
 if not s.scalar(select(System).where(System.id==x.system_id,System.org_id==u.org_id)):raise HTTPException(404,'Système introuvable')
 r=Restore(org_id=u.org_id,**x.model_dump());s.add(r);s.commit();return r
@app.get('/dashboard')
def dashboard(u:User=Depends(current),s:Session=Depends(db)):
 xs=systems(u,s);return {'readiness':round(sum(x['score'] for x in xs)/len(xs)) if xs else 0,'systems_total':len(xs),'systems_protected':sum(x['score']>=40 for x in xs),'alerts':sum(x['score']<40 for x in xs),'items':xs}
@app.get('/auth/mfa/status')
def mfa_status(u:User=Depends(current),s:Session=Depends(db)):m=s.scalar(select(MFA).where(MFA.user_id==u.id));return {'enabled':bool(m and m.enabled)}
@app.post('/auth/mfa/setup')
def mfa_setup(u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):
 sec=pyotp.random_base32();m=s.scalar(select(MFA).where(MFA.user_id==u.id)) or MFA(user_id=u.id,secret='');m.secret=FERNET.encrypt(sec.encode()).decode();m.enabled=False;s.add(m);s.commit();return {'secret':sec,'otpauth_uri':pyotp.TOTP(sec).provisioning_uri(u.email,issuer_name='RecoveryProof')}
@app.post('/auth/mfa/enable')
def mfa_enable(x:MFAEnable=Body(...),u:User=Depends(current),s:Session=Depends(db),ok=Depends(csrf)):
 m=s.scalar(select(MFA).where(MFA.user_id==u.id));sec=FERNET.decrypt(m.secret.encode()).decode()
 if not pyotp.TOTP(sec).verify(x.code,valid_window=1):raise HTTPException(400,'Code invalide')
 m.enabled=True;s.commit();return {'enabled':True}
