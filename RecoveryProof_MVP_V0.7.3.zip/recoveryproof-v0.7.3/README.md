# RecoveryProof V0.7.3 complet

Archive autonome contenant RecoveryProof, PostgreSQL, Prometheus et Grafana.

## Démarrage
```bash
make up
make observability
```
Ports: application 8080, Prometheus 9090, Grafana 3000.

## Grafana
Utilisateur `admin`. Mot de passe généré par `make grafana-password`. Le dashboard provisionné contient neuf panneaux: disponibilité actuelle et 6 h, taux et volume 5xx, connexions refusées, débit, latence P95, statuts HTTP et rate limiting.

## Sécurité
Sessions serveur par cookie HttpOnly SameSite Strict, protection CSRF, mots de passe Argon2 et MFA TOTP chiffré. En production HTTPS, passer `COOKIE_SECURE` à `true`.
