# Authentification V0.7

## Session
Le navigateur reçoit `rp_session`, un identifiant opaque aléatoire de 384 bits dans un cookie HttpOnly, SameSite=Strict, limité à 30 minutes. La base ne conserve que son empreinte HMAC-SHA256. `rp_csrf` est un second cookie lisible par le frontend et doit correspondre à l'en-tête `X-CSRF-Token` sur les écritures.

Pour le laboratoire HTTP local, `COOKIE_SECURE=false`. En production HTTPS, imposer `COOKIE_SECURE=true`.

## MFA TOTP
Le secret TOTP est chiffré avec Fernet à partir de la clé applicative, puis stocké dans `user_mfa`. Activation depuis Paramètres avec Microsoft Authenticator, Google Authenticator ou FreeOTP. Une dérive maximale d'une période de 30 secondes est acceptée de chaque côté (`valid_window=1`).

## Limites avant production
Ajouter des codes de récupération hachés, la désactivation MFA avec réauthentification, la rotation de la clé Fernet, une politique de sessions concurrentes, une notification e-mail de connexion et des tests d'intégration navigateur.
