#!/bin/sh
set -eu
export DB_PASSWORD="$(cat /run/secrets/db_password)"
export APP_SECRET="$(cat /run/secrets/app_secret)"
cd /app
HAS_USERS="$(python - <<'PY'
from sqlalchemy import inspect
from app.main import engine
print('yes' if inspect(engine).has_table('users') else 'no')
PY
)"
if [ "$HAS_USERS" = "no" ]; then
  python - <<'PY'
from app.main import Base,engine
Base.metadata.create_all(engine)
PY
  alembic -c alembic.ini stamp head
else
  if ! alembic -c alembic.ini current 2>/dev/null | grep -q .; then
    alembic -c alembic.ini stamp 0001_baseline
  fi
  alembic -c alembic.ini upgrade head
fi
exec su -s /bin/sh app -c 'exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers'
