"""server-side web sessions and encrypted TOTP MFA"""
from alembic import op
import sqlalchemy as sa
revision='0002_secure_sessions_mfa'
down_revision='0001_baseline'
branch_labels=None
depends_on=None
def upgrade():
 op.create_table('web_sessions',
  sa.Column('id',sa.Integer(),primary_key=True),
  sa.Column('user_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),
  sa.Column('session_digest',sa.String(64),nullable=False),
  sa.Column('csrf_digest',sa.String(64),nullable=False),
  sa.Column('expires_at',sa.DateTime(timezone=True),nullable=False),
  sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
  sa.Column('last_seen',sa.DateTime(timezone=True),nullable=False),
  sa.Column('revoked_at',sa.DateTime(timezone=True),nullable=True),
  sa.Column('ip_hash',sa.String(64),nullable=True))
 op.create_index('ix_web_sessions_user_id','web_sessions',['user_id'])
 op.create_index('ix_web_sessions_session_digest','web_sessions',['session_digest'],unique=True)
 op.create_index('ix_web_sessions_expires_at','web_sessions',['expires_at'])
 op.create_table('user_mfa',
  sa.Column('id',sa.Integer(),primary_key=True),
  sa.Column('user_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),
  sa.Column('secret_encrypted',sa.Text(),nullable=False),
  sa.Column('enabled',sa.Boolean(),nullable=False,server_default=sa.false()),
  sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
  sa.Column('enabled_at',sa.DateTime(timezone=True),nullable=True))
 op.create_index('ix_user_mfa_user_id','user_mfa',['user_id'],unique=True)
def downgrade():
 op.drop_index('ix_user_mfa_user_id',table_name='user_mfa');op.drop_table('user_mfa')
 op.drop_index('ix_web_sessions_expires_at',table_name='web_sessions');op.drop_index('ix_web_sessions_session_digest',table_name='web_sessions');op.drop_index('ix_web_sessions_user_id',table_name='web_sessions');op.drop_table('web_sessions')
