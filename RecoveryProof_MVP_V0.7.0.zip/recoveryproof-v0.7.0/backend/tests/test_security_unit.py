import ast
from pathlib import Path
SRC=Path(__file__).parents[1]/'app/main.py'
def text():return SRC.read_text()
def test_tenant_filters_present():
 s=text();assert 'model.id==i,model.org_id==org' in s;assert "Crisis.org_id==u.org_id" in s;assert "System.org_id==u.org_id" in s
def test_password_hash_and_token_digest():
 s=text();assert 'PasswordHasher' in s;assert 'hmac.new' in s;assert 'token_digest' in s
def test_no_hardcoded_secret():
 s=text();assert 'DB_PASSWORD=os.environ' in s;assert 'APP_SECRET' in s;assert 'password123' not in s.lower()
def test_python_syntax():ast.parse(text())

def test_server_side_sessions_csrf_and_mfa():
    s=text()
    assert "class WebSession" in s
    assert "httponly=True" in s
    assert "samesite='strict'" in s
    assert "def require_csrf" in s
    assert "class UserMFA" in s
    assert "Fernet" in s
    assert "pyotp.TOTP" in s
