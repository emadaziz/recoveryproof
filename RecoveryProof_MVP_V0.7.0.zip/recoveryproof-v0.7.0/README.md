# RecoveryProof V0.7.0

V0.7 remplace le JWT stocké dans `sessionStorage` par des sessions serveur avec cookie HttpOnly, protection CSRF et MFA TOTP optionnelle.

## Nouveautés
- cookie de session opaque 384 bits, HttpOnly et SameSite=Strict;
- empreinte HMAC-SHA256 en PostgreSQL, jamais le jeton brut;
- révocation serveur à la déconnexion;
- protection CSRF sur les écritures métier;
- MFA TOTP compatible Microsoft Authenticator, Google Authenticator et FreeOTP;
- secret MFA chiffré avec Fernet;
- migration Alembic `0002_secure_sessions_mfa`;
- Prometheus et Grafana conservés.

## Démarrage laboratoire
```bash
make up
make observability
make migration-check
make test
```

## Production
Configurer `COOKIE_SECURE=true` derrière HTTPS. Ne pas exposer Grafana publiquement. Avant client externe, ajouter codes de récupération MFA, réinitialisation SMTP réelle, tests Playwright complets et pentest OWASP ASVS niveau 2.
