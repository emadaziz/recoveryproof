# Sécurité V0.4
Argon2id, JWT 30 minutes, jetons agents sous empreinte HMAC, isolation org_id, secrets Docker absents de Git, conteneur API read-only, capacités supprimées sauf SETUID/SETGID à l'entrée. Avant production: OIDC/MFA, cookies HttpOnly Secure SameSite, Alembic, TLS, sauvegardes testées, SAST/SCA/DAST et pentest OWASP ASVS L2.
