# Sécurité V0.2
- Mots de passe hachés avec Argon2id (64 Mio, 3 passes, parallélisme 2).
- Session JWT 30 minutes en mémoire de session du navigateur; aucun secret applicatif dans JavaScript.
- Jetons agent 256 bits, affichés une fois, stockés sous empreinte HMAC-SHA256, expirables et révocables.
- Isolation par `org_id` sur chaque lecture et écriture métier.
- Limitation: initialisation 3/minute, connexion 5/minute.
- API non documentée publiquement (`/docs` désactivé), CSP et en-têtes de sécurité Nginx.
- Conteneur API non privilégié, lecture seule, capacités Linux supprimées.
- Agent non privilégié, volume cible monté en lecture seule.
- Journal d'audit pour initialisation, systèmes, agents et restaurations.

Avant production: HTTPS obligatoire, OIDC+MFA/WebAuthn, rotation de clés, Alembic, sauvegardes testées, scan Trivy, SBOM CycloneDX, SAST, DAST OWASP ZAP, revue ASVS L2 et pentest indépendant.
