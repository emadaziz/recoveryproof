import os, json, urllib.request
from pathlib import Path
from datetime import datetime, timezone
API=os.environ['RP_API_URL'].rstrip('/')
TOKEN=os.environ['RP_AGENT_TOKEN']
SYSTEM_ID=int(os.environ['RP_SYSTEM_ID'])
WATCH=Path(os.environ.get('RP_WATCH_PATH','/data'))
files=[p for p in WATCH.rglob('*') if p.is_file()]
newest=max((p.stat().st_mtime for p in files),default=None)
payload={'system_id':SYSTEM_ID,'status':'ok' if files else 'warning','newest_file_at':datetime.fromtimestamp(newest,timezone.utc).isoformat() if newest else None,'file_count':len(files),'total_bytes':sum(p.stat().st_size for p in files),'details':'Contrôle de métadonnées filesystem'}
req=urllib.request.Request(API+'/api/agent/checks',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+TOKEN},method='POST')
with urllib.request.urlopen(req,timeout=20) as r: print(r.read().decode())
