from __future__ import annotations
import os, secrets, hashlib, hmac, time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional
import jwt
from argon2 import PasswordHasher
from fastapi import FastAPI, Depends, HTTPException, Request, Response, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Integer, DateTime, ForeignKey, Boolean, Float, Text, select, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker, Session
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

UTC=timezone.utc
def now(): return datetime.now(UTC)
def secret(path_env, default): return Path(os.getenv(path_env, default)).read_text().strip()
DB_PASSWORD=secret('DB_PASSWORD_FILE','/run/secrets/db_password')
JWT_SECRET=secret('APP_SECRET_FILE','/run/secrets/app_secret')
DATABASE_URL=os.getenv('DATABASE_URL',f'postgresql+psycopg://recoveryproof:{DB_PASSWORD}@db/recoveryproof')
engine=create_engine(DATABASE_URL,pool_pre_ping=True)
SessionLocal=sessionmaker(engine,expire_on_commit=False)
ph=PasswordHasher(time_cost=3,memory_cost=65536,parallelism=2)
oauth=OAuth2PasswordBearer(tokenUrl='/api/auth/login')
limiter=Limiter(key_func=get_remote_address)

class Base(DeclarativeBase): pass
class Org(Base):
    __tablename__='orgs'; id:Mapped[int]=mapped_column(primary_key=True); name:Mapped[str]=mapped_column(String(120)); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class User(Base):
    __tablename__='users'; id:Mapped[int]=mapped_column(primary_key=True); org_id:Mapped[int]=mapped_column(ForeignKey('orgs.id')); email:Mapped[str]=mapped_column(String(254),unique=True,index=True); password_hash:Mapped[str]=mapped_column(Text); role:Mapped[str]=mapped_column(String(30),default='admin'); active:Mapped[bool]=mapped_column(Boolean,default=True)
class System(Base):
    __tablename__='systems'; id:Mapped[int]=mapped_column(primary_key=True); org_id:Mapped[int]=mapped_column(ForeignKey('orgs.id'),index=True); name:Mapped[str]=mapped_column(String(120)); criticality:Mapped[str]=mapped_column(String(20)); rpo_hours:Mapped[int]=mapped_column(Integer); rto_hours:Mapped[int]=mapped_column(Integer); owner:Mapped[Optional[str]]=mapped_column(String(120),nullable=True); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Agent(Base):
    __tablename__='agents'; id:Mapped[int]=mapped_column(primary_key=True); org_id:Mapped[int]=mapped_column(ForeignKey('orgs.id'),index=True); name:Mapped[str]=mapped_column(String(120)); token_digest:Mapped[str]=mapped_column(String(64),unique=True,index=True); scopes:Mapped[str]=mapped_column(String(250),default='checks:write'); revoked:Mapped[bool]=mapped_column(Boolean,default=False); expires_at:Mapped[datetime]=mapped_column(DateTime(timezone=True)); last_seen:Mapped[Optional[datetime]]=mapped_column(DateTime(timezone=True),nullable=True); created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Check(Base):
    __tablename__='checks'; id:Mapped[int]=mapped_column(primary_key=True); org_id:Mapped[int]=mapped_column(ForeignKey('orgs.id'),index=True); system_id:Mapped[int]=mapped_column(ForeignKey('systems.id'),index=True); agent_id:Mapped[int]=mapped_column(ForeignKey('agents.id')); status:Mapped[str]=mapped_column(String(20)); newest_file_at:Mapped[Optional[datetime]]=mapped_column(DateTime(timezone=True),nullable=True); file_count:Mapped[int]=mapped_column(Integer); total_bytes:Mapped[int]=mapped_column(Integer); details:Mapped[Optional[str]]=mapped_column(Text,nullable=True); received_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,index=True)
class RestoreTest(Base):
    __tablename__='restore_tests'; id:Mapped[int]=mapped_column(primary_key=True); org_id:Mapped[int]=mapped_column(ForeignKey('orgs.id'),index=True); system_id:Mapped[int]=mapped_column(ForeignKey('systems.id')); result:Mapped[str]=mapped_column(String(20)); duration_minutes:Mapped[int]=mapped_column(Integer); notes:Mapped[Optional[str]]=mapped_column(Text,nullable=True); tested_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Audit(Base):
    __tablename__='audit'; id:Mapped[int]=mapped_column(primary_key=True); org_id:Mapped[int]=mapped_column(index=True); actor:Mapped[str]=mapped_column(String(254)); action:Mapped[str]=mapped_column(String(100)); resource:Mapped[str]=mapped_column(String(150)); at:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class Bootstrap(BaseModel): org_name:str=Field(min_length=2,max_length=120); email:str=Field(min_length=5,max_length=254); password:str=Field(min_length=12,max_length=200)
class Login(BaseModel): email:str; password:str
class SystemIn(BaseModel): name:str=Field(min_length=2,max_length=120); criticality:str=Field(pattern='^(low|medium|high|critical)$'); rpo_hours:int=Field(ge=1,le=8760); rto_hours:int=Field(ge=1,le=8760); owner:Optional[str]=Field(default=None,max_length=120)
class AgentIn(BaseModel): name:str=Field(min_length=2,max_length=120); expires_days:int=Field(default=30,ge=1,le=365)
class CheckIn(BaseModel): system_id:int; status:str=Field(pattern='^(ok|warning|critical)$'); newest_file_at:Optional[datetime]=None; file_count:int=Field(ge=0); total_bytes:int=Field(ge=0); details:Optional[str]=Field(default=None,max_length=1000)
class RestoreIn(BaseModel): system_id:int; result:str=Field(pattern='^(success|partial|failed)$'); duration_minutes:int=Field(ge=0,le=100000); notes:Optional[str]=Field(default=None,max_length=2000)

def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()
def digest(t): return hmac.new(JWT_SECRET.encode(),t.encode(),hashlib.sha256).hexdigest()
def token_for(u): return jwt.encode({'sub':str(u.id),'org':u.org_id,'role':u.role,'exp':now()+timedelta(minutes=30)},JWT_SECRET,algorithm='HS256')
def current(token:str=Depends(oauth),s:Session=Depends(db)):
    try: data=jwt.decode(token,JWT_SECRET,algorithms=['HS256']); u=s.get(User,int(data['sub']))
    except Exception: raise HTTPException(401,'Session invalide ou expirée')
    if not u or not u.active: raise HTTPException(401,'Compte inactif')
    return u
def audit(s,u,action,res): s.add(Audit(org_id=u.org_id,actor=u.email,action=action,resource=res))
def only_org(s,model,obj_id,org):
    obj=s.scalar(select(model).where(model.id==obj_id,model.org_id==org))
    if not obj: raise HTTPException(404,'Ressource introuvable')
    return obj

app=FastAPI(title='RecoveryProof API',version='0.2.0',docs_url=None,redoc_url=None)
app.state.limiter=limiter; app.add_exception_handler(RateLimitExceeded,lambda r,e: Response('Trop de requêtes',status_code=429)); app.add_middleware(SlowAPIMiddleware)
app.add_middleware(CORSMiddleware,allow_origins=[x for x in os.getenv('ALLOWED_ORIGINS','http://localhost:8080').split(',') if x],allow_methods=['GET','POST','PUT','DELETE'],allow_headers=['Authorization','Content-Type'],allow_credentials=False)
@app.on_event('startup')
def startup(): Base.metadata.create_all(engine)
@app.get('/health')
def health(): return {'status':'ok','version':'0.2.0','time':now()}
@app.get('/setup/status')
def setup_status(s:Session=Depends(db)): return {'required':(s.scalar(select(func.count(User.id))) or 0)==0}
@app.post('/setup/bootstrap',status_code=201)
@limiter.limit('3/minute')
def bootstrap(request:Request,x:Bootstrap,s:Session=Depends(db)):
    if (s.scalar(select(func.count(User.id))) or 0)>0: raise HTTPException(409,'Initialisation déjà effectuée')
    org=Org(name=x.org_name); s.add(org); s.flush(); u=User(org_id=org.id,email=x.email.lower(),password_hash=ph.hash(x.password),role='admin'); s.add(u); s.flush(); audit(s,u,'bootstrap','organization'); s.commit(); return {'access_token':token_for(u),'token_type':'bearer'}
@app.post('/auth/login')
@limiter.limit('5/minute')
def login(request:Request,x:Login,s:Session=Depends(db)):
    u=s.scalar(select(User).where(User.email==x.email.lower()))
    try: ok=bool(u and ph.verify(u.password_hash,x.password))
    except Exception: ok=False
    if not ok: time.sleep(.4); raise HTTPException(401,'Identifiants invalides')
    return {'access_token':token_for(u),'token_type':'bearer'}
@app.get('/me')
def me(u:User=Depends(current),s:Session=Depends(db)): return {'email':u.email,'role':u.role,'organization':s.get(Org,u.org_id).name}
@app.get('/systems')
def systems(u:User=Depends(current),s:Session=Depends(db)): return s.scalars(select(System).where(System.org_id==u.org_id).order_by(System.name)).all()
@app.post('/systems',status_code=201)
def add_system(x:SystemIn,u:User=Depends(current),s:Session=Depends(db)):
    obj=System(org_id=u.org_id,**x.model_dump()); s.add(obj); s.flush(); audit(s,u,'system.create',str(obj.id)); s.commit(); s.refresh(obj); return obj
@app.delete('/systems/{sid}',status_code=204)
def del_system(sid:int,u:User=Depends(current),s:Session=Depends(db)):
    obj=only_org(s,System,sid,u.org_id); s.delete(obj); audit(s,u,'system.delete',str(sid)); s.commit()
@app.get('/agents')
def agents(u:User=Depends(current),s:Session=Depends(db)):
    return [{'id':a.id,'name':a.name,'revoked':a.revoked,'expires_at':a.expires_at,'last_seen':a.last_seen} for a in s.scalars(select(Agent).where(Agent.org_id==u.org_id)).all()]
@app.post('/agents',status_code=201)
def add_agent(x:AgentIn,u:User=Depends(current),s:Session=Depends(db)):
    raw='rpa_'+secrets.token_urlsafe(32); a=Agent(org_id=u.org_id,name=x.name,token_digest=digest(raw),expires_at=now()+timedelta(days=x.expires_days)); s.add(a); s.flush(); audit(s,u,'agent.create',str(a.id)); s.commit(); return {'id':a.id,'token':raw,'warning':'Copiez ce jeton maintenant. Il ne sera plus affiché.'}
@app.post('/agents/{aid}/revoke')
def revoke(aid:int,u:User=Depends(current),s:Session=Depends(db)):
    a=only_org(s,Agent,aid,u.org_id); a.revoked=True; audit(s,u,'agent.revoke',str(aid)); s.commit(); return {'revoked':True}
def agent_auth(authorization:str=Header(default=''),s:Session=Depends(db)):
    if not authorization.startswith('Bearer rpa_'): raise HTTPException(401,'Jeton agent requis')
    a=s.scalar(select(Agent).where(Agent.token_digest==digest(authorization[7:])))
    if not a or a.revoked or a.expires_at<now(): raise HTTPException(403,'Jeton agent invalide, expiré ou révoqué')
    return a
@app.post('/agent/checks',status_code=202)
def ingest(x:CheckIn,a:Agent=Depends(agent_auth),s:Session=Depends(db)):
    only_org(s,System,x.system_id,a.org_id); a.last_seen=now(); c=Check(org_id=a.org_id,agent_id=a.id,**x.model_dump()); s.add(c); s.commit(); return {'accepted':True}
@app.post('/restore-tests',status_code=201)
def restore(x:RestoreIn,u:User=Depends(current),s:Session=Depends(db)):
    only_org(s,System,x.system_id,u.org_id); r=RestoreTest(org_id=u.org_id,**x.model_dump()); s.add(r); s.flush(); audit(s,u,'restore.create',str(r.id)); s.commit(); return r
@app.get('/dashboard')
def dashboard(u:User=Depends(current),s:Session=Depends(db)):
    systems=s.scalars(select(System).where(System.org_id==u.org_id)).all(); items=[]; alerts=0; tested=0
    for sys in systems:
        c=s.scalar(select(Check).where(Check.org_id==u.org_id,Check.system_id==sys.id).order_by(Check.received_at.desc()))
        rt=s.scalar(select(RestoreTest).where(RestoreTest.org_id==u.org_id,RestoreTest.system_id==sys.id).order_by(RestoreTest.tested_at.desc()))
        age=None; state='never_checked'
        if c and c.newest_file_at:
            age=max(0,(now()-c.newest_file_at).total_seconds()/3600); state='ok' if age<=sys.rpo_hours and c.status=='ok' else 'alert'
        if state!='ok': alerts+=1
        if rt and rt.result=='success': tested+=1
        items.append({'id':sys.id,'name':sys.name,'rpo_hours':sys.rpo_hours,'rto_hours':sys.rto_hours,'backup_age_hours':round(age,1) if age is not None else None,'state':state,'last_check':c.received_at if c else None,'restore_result':rt.result if rt else None})
    total=len(systems); protected=sum(1 for i in items if i['state']=='ok'); readiness=round(((protected+tested)/(2*total))*100) if total else 0
    return {'readiness':readiness,'systems_total':total,'systems_protected':protected,'alerts':alerts,'restores_verified':tested,'items':items}
@app.get('/audit')
def audits(u:User=Depends(current),s:Session=Depends(db)): return s.scalars(select(Audit).where(Audit.org_id==u.org_id).order_by(Audit.at.desc()).limit(100)).all()
