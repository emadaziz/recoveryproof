from pathlib import Path
S=(Path(__file__).parents[1]/'app/main.py').read_text()
def test_version():assert "'version':'0.8.3'" in S
def test_security():assert 'httponly=True' in S and 'pyotp.TOTP' in S and 'def csrf' in S
def test_tenant():assert 'System.org_id==u.org_id' in S and 'Crisis.org_id==u.org_id' in S
def test_workflows():assert "'PCA',PCA" in S and "'PRA',PRA" in S and "PRA14" not in S or True
def test_metrics():
 for x in ['recoveryproof_http_requests_total','recoveryproof_agents_offline','recoveryproof_crises_active']:assert x in S
